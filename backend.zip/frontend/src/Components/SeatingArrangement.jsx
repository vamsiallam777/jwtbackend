import React, { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import {
  Box, Button, Typography, Paper, Grid, Card, CardContent, 
  FormControl, InputLabel, Select, MenuItem, TableContainer, 
  Table, TableHead, TableRow, TableCell, TableBody, Checkbox, 
  IconButton, Chip, Dialog, DialogTitle, DialogContent, 
  DialogActions, DialogContentText, Snackbar, Alert, 
  CircularProgress, Tabs, Tab, Divider, Stack, TextField
} from '@mui/material';
import {
  CalendarToday as CalendarTodayIcon,
  MeetingRoom as MeetingRoomIcon,
  EventSeat as EventSeatIcon,
  Delete as DeleteIcon,
  Print as PrintIcon,
  Download as DownloadIcon,
  TableChart as TableChartIcon,
  Refresh as RefreshIcon,
  AccessTime as AccessTimeIcon
} from '@mui/icons-material';
import { LocalizationProvider, DatePicker } from '@mui/x-date-pickers';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
import { format } from 'date-fns';

const buttonStyle = {
  background: 'linear-gradient(135deg, #1e3c72 0%, #2a5298 100%)',
  '&:hover': {
    background: 'linear-gradient(135deg, #2a5298 0%, #1e3c72 100%)',
  }
};

function SeatingArrangement() {
  const navigate = useNavigate();
  const location = useLocation();
  const queryParams = new URLSearchParams(location.search);
  const examIdFromUrl = queryParams.get('examId');
  const roomIdFromUrl = queryParams.get('roomId');

  // State variables
  const [selectedDate, setSelectedDate] = useState(null);
  const [exams, setExams] = useState([]);
  const [selectedExams, setSelectedExams] = useState([]);  
  const [selectedExam, setSelectedExam] = useState(null);  
  const [availableRooms, setAvailableRooms] = useState([]);
  const [selectedRooms, setSelectedRooms] = useState([]);
  const [seatingArrangements, setSeatingArrangements] = useState([]);
  const [loading, setLoading] = useState(false);
  const [examsLoading, setExamsLoading] = useState(false);
  const [roomsLoading, setRoomsLoading] = useState(false);
  const [generateLoading, setGenerateLoading] = useState(false);
  const [viewArrangementDialog, setViewArrangementDialog] = useState(false);
  const [snackbarOpen, setSnackbarOpen] = useState(false);
  const [snackbarData, setSnackbarData] = useState({ message: '', severity: 'info' });
  const [blockFilter, setBlockFilter] = useState('all');
  const [floorFilter, setFloorFilter] = useState('all');
  const [currentTab, setCurrentTab] = useState(0);
  const [arrangementsByRoom, setArrangementsByRoom] = useState({});
  const [selectedRoomForView, setSelectedRoomForView] = useState(null);
  const [examsWithArrangements, setExamsWithArrangements] = useState({});
  const [confirmDeleteDialog, setConfirmDeleteDialog] = useState(false);
  const [examToDelete, setExamToDelete] = useState(null);
  const [deleteLoading, setDeleteLoading] = useState(false);
  
  // New state variables
  const [examsWithExistingArrangements, setExamsWithExistingArrangements] = useState([]);
  const [roomsWithSeatingArrangements, setRoomsWithSeatingArrangements] = useState([]);
  const [loadingExistingArrangements, setLoadingExistingArrangements] = useState(false);
  const [mainViewTab, setMainViewTab] = useState(0);
  const [selectedRoomArrangements, setSelectedRoomArrangements] = useState([]);
  const [roomDetailsLoading, setRoomDetailsLoading] = useState(false);
  const [selectedRoomDetails, setSelectedRoomDetails] = useState(null);
  const [selectedDateForRooms, setSelectedDateForRooms] = useState(null);
  const [loadingRoomsByDate, setLoadingRoomsByDate] = useState(false);
  const [roomsWithBookings, setRoomsWithBookings] = useState([]);
  const [timeFilterRange, setTimeFilterRange] = useState({ start: '', end: '' });

  useEffect(() => {
    // Check authentication
    const token = localStorage.getItem('token');
    if (!token) {
      navigate('/login');
      return;
    }

    // Initialize based on URL parameters
    if (examIdFromUrl) {
      fetchExamById(examIdFromUrl);
    } else if (roomIdFromUrl) {
      fetchRoomArrangements(roomIdFromUrl);
      setMainViewTab(1); // Switch to existing arrangements tab
    } else {
      // Default loading - fetch existing arrangements data
      fetchExamsWithExistingArrangements();
      fetchRoomsWithArrangements();
    }
  }, [navigate, examIdFromUrl, roomIdFromUrl]);

  // Function to fetch all exams that have seating arrangements
  const fetchExamsWithExistingArrangements = async () => {
    try {
      setLoadingExistingArrangements(true);
      const token = localStorage.getItem('token');
      const response = await fetch('http://localhost:8081/api/seating-arrangements/existing-arrangements', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      
      if (response.ok) {
        const data = await response.json();
        setExamsWithExistingArrangements(data);
      } else if (response.status === 401) {
        navigate('/login');
      } else {
        showSnackbar('Failed to fetch existing arrangements', 'error');
      }
    } catch (error) {
      console.error('Error fetching existing arrangements:', error);
      showSnackbar('Error fetching existing arrangements', 'error');
    } finally {
      setLoadingExistingArrangements(false);
    }
  };
  
  // Function to fetch rooms with arrangements
  const fetchRoomsWithArrangements = async () => {
    try {
      setLoadingExistingArrangements(true);
      const token = localStorage.getItem('token');
      const response = await fetch('http://localhost:8081/api/seating-arrangements/rooms-with-arrangements', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      
      if (response.ok) {
        const data = await response.json();
        console.log("Rooms with arrangements:", data);
        setRoomsWithSeatingArrangements(data);
      } else if (response.status === 401) {
        navigate('/login');
      } else {
        showSnackbar('Failed to fetch rooms with arrangements', 'error');
      }
    } catch (error) {
      console.error('Error fetching rooms with arrangements:', error);
      showSnackbar('Error fetching rooms with arrangements', 'error');
    } finally {
      setLoadingExistingArrangements(false);
    }
  };
  
  // Function to fetch arrangements for a specific room
  const fetchRoomArrangements = async (roomId) => {
    try {
      setRoomDetailsLoading(true);
      const token = localStorage.getItem('token');
      const response = await fetch(`http://localhost:8081/api/seating-arrangements/room/${roomId}`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      
      if (response.ok) {
        const data = await response.json();
        
        // Find the room details in the existing data or retrieve separately if needed
        const roomDetails = roomsWithSeatingArrangements.find(room => room.roomId === parseInt(roomId)) || 
                           { roomId: parseInt(roomId), roomNumber: "Loading...", studentCount: data.length };
        
        setSelectedRoomDetails(roomDetails);
        setSelectedRoomArrangements(data);
        
        // Group by room for room view
        const byRoom = {};
        byRoom[roomId] = data;
        setArrangementsByRoom(byRoom);
        
        // Set selected room for view
        setSelectedRoomForView(parseInt(roomId));
        
        // Open dialog to view arrangements
        setViewArrangementDialog(true);
      } else if (response.status === 401) {
        navigate('/login');
      } else {
        showSnackbar('Failed to fetch room arrangements', 'error');
      }
    } catch (error) {
      console.error('Error fetching room arrangements:', error);
      showSnackbar('Error fetching room arrangements', 'error');
    } finally {
      setRoomDetailsLoading(false);
    }
  };

  // Function to fetch an exam by ID (for direct URL access)
  const fetchExamById = async (examId) => {
    try {
      setLoading(true);
      const token = localStorage.getItem('token');
      const response = await fetch(`http://localhost:8081/api/exams/${examId}`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      
      if (response.ok) {
        const examData = await response.json();
        setSelectedExam(examData);
        setSelectedExams([examData]);
        
        // Fetch rooms for this exam
        fetchAvailableRooms(examId);
        
        // Check if seating arrangements already exist
        fetchExistingArrangements(examId);
      } else if (response.status === 401) {
        navigate('/login');
      } else {
        showSnackbar('Failed to fetch exam details', 'error');
      }
    } catch (error) {
      console.error('Error fetching exam details:', error);
      showSnackbar('Error fetching exam details', 'error');
    } finally {
      setLoading(false);
    }
  };

  // Function to fetch rooms with arrangements by date
  const fetchRoomsByDate = async (date) => {
    if (!date) return;
    
    try {
      setLoadingRoomsByDate(true);
      const token = localStorage.getItem('token');
      const formattedDate = format(date, 'yyyy-MM-dd');
      console.log(`Fetching rooms for date: ${formattedDate}`);
      
      const response = await fetch(`http://localhost:8081/api/seating-arrangements/rooms-with-arrangements/date/${formattedDate}`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      
      if (response.ok) {
        const data = await response.json();
        console.log("Rooms with bookings:", data);
        setRoomsWithBookings(data);
      } else if (response.status === 401) {
        navigate('/login');
      } else {
        console.error(`Failed to fetch rooms: ${response.status}`);
        showSnackbar('Failed to fetch rooms for the selected date', 'error');
      }
    } catch (error) {
      console.error('Error fetching rooms by date:', error);
      showSnackbar('Error fetching rooms for the selected date', 'error');
    } finally {
      setLoadingRoomsByDate(false);
    }
  };

  // Check which exams have existing arrangements when exams are loaded
  useEffect(() => {
    if (exams && exams.length > 0) {
      checkExistingArrangements(exams);
    }
  }, [exams]);

  const checkExistingArrangements = async (examsList) => {
    try {
      const token = localStorage.getItem('token');
      const arrangements = {};
      
      // Check each exam
      for (const exam of examsList) {
        const response = await fetch(`http://localhost:8081/api/seating-arrangements/exists/${exam.id}`, {
          headers: {
            'Authorization': `Bearer ${token}`
          }
        });
        
        if (response.ok) {
          const data = await response.json();
          arrangements[exam.id] = data.exists;
        }
      }
      
      setExamsWithArrangements(arrangements);
    } catch (error) {
      console.error('Error checking existing arrangements:', error);
    }
  };

  const fetchExamsByDate = async (date) => {
    try {
      setExamsLoading(true);
      const token = localStorage.getItem('token');
      const formattedDate = format(date, 'yyyy-MM-dd');
      
      const response = await fetch(`http://localhost:8081/api/seating-arrangements/exams/date/${formattedDate}`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      
      if (response.ok) {
        const data = await response.json();
        setExams(data);
        
        // Reset selections
        setSelectedExam(null);
        setSelectedExams([]);
        setAvailableRooms([]);
        setSelectedRooms([]);
      } else if (response.status === 401) {
        navigate('/login');
      } else {
        showSnackbar('Failed to fetch exams for the selected date', 'error');
      }
    } catch (error) {
      console.error('Error fetching exams by date:', error);
      showSnackbar('Error fetching exams', 'error');
    } finally {
      setExamsLoading(false);
    }
  };

  const fetchExistingArrangements = async (examId) => {
    try {
      setLoading(true);
      const token = localStorage.getItem('token');
      const response = await fetch(`http://localhost:8081/api/seating-arrangements/exam/${examId}`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      
      if (response.ok) {
        const data = await response.json();
        setSeatingArrangements(data);
        
        // Group by room for easy display
        const byRoom = {};
        for (const arr of data) {
          if (!byRoom[arr.roomId]) {
            byRoom[arr.roomId] = [];
          }
          byRoom[arr.roomId].push(arr);
        }
        
        setArrangementsByRoom(byRoom);
      }
    } catch (error) {
      console.error('Error fetching existing arrangements:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleDateChange = (date) => {
    setSelectedDate(date);
    if (date) {
      fetchExamsByDate(date);
    } else {
      setExams([]);
      setSelectedExam(null);
      setSelectedExams([]);
      setAvailableRooms([]);
      setSelectedRooms([]);
    }
  };

  const handleExamSelect = (exam) => {
    const examId = exam.id;
    const isSelected = selectedExams.some(e => e.id === examId);
    
    if (isSelected) {
      setSelectedExams(selectedExams.filter(e => e.id !== examId));
      if (selectedExam?.id === examId) {
        setSelectedExam(null);
        setAvailableRooms([]);
        setSelectedRooms([]);
      }
    } else {
      setSelectedExams([...selectedExams, exam]);
      if (!selectedExam) {
        handlePrimaryExamSelect(exam);
      }
    }
  };
  
  const handlePrimaryExamSelect = (exam) => {
    setSelectedExam(exam);
    fetchAvailableRooms(exam.id);
    
    // Add to selected exams if not already there
    if (!selectedExams.some(e => e.id === exam.id)) {
      setSelectedExams([...selectedExams, exam]);
    }
  };
  
  const fetchAvailableRooms = async (examId) => {
    try {
      setRoomsLoading(true);
      const token = localStorage.getItem('token');
      
      const response = await fetch(`http://localhost:8081/api/seating-arrangements/available-rooms/${examId}`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      
      if (response.ok) {
        const data = await response.json();
        setAvailableRooms(data);
        setSelectedRooms([]);
      } else if (response.status === 401) {
        navigate('/login');
      } else {
        showSnackbar('Failed to fetch available rooms', 'error');
      }
    } catch (error) {
      console.error('Error fetching available rooms:', error);
      showSnackbar('Error fetching available rooms', 'error');
    } finally {
      setRoomsLoading(false);
    }
  };
  
  const handleRoomToggle = (roomId) => {
    const isSelected = selectedRooms.includes(roomId);
    
    if (isSelected) {
      setSelectedRooms(selectedRooms.filter(id => id !== roomId));
    } else {
      setSelectedRooms([...selectedRooms, roomId]);
    }
  };
  
  const getFilteredRooms = () => {
    return availableRooms.filter(room => {
      const blockMatch = blockFilter === 'all' || room.blockName === blockFilter;
      const floorMatch = floorFilter === 'all' || room.floorNumber.toString() === floorFilter;
      
      return blockMatch && floorMatch;
    });
  };
  
  const getUniqueBlocks = () => {
    const blocks = availableRooms.map(room => room.blockName);
    return [...new Set(blocks)];
  };
  
  const getUniqueFloors = () => {
    const floors = availableRooms
      .filter(room => blockFilter === 'all' || room.blockName === blockFilter)
      .map(room => room.floorNumber.toString());
    
    return [...new Set(floors)];
  };
  
  const generateSeatingArrangement = async () => {
    try {
      setGenerateLoading(true);
      
      if (!selectedExam) {
        showSnackbar('Please select a primary exam', 'error');
        return;
      }
      
      if (selectedRooms.length === 0) {
        showSnackbar('Please select at least one room', 'error');
        return;
      }
      
      const token = localStorage.getItem('token');
      
      if (selectedExams.length === 1) {
        // Single exam arrangement
        const payload = {
          examId: selectedExam.id,
          roomIds: selectedRooms
        };
        
        const response = await fetch('http://localhost:8081/api/seating-arrangements/generate', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
          },
          body: JSON.stringify(payload)
        });
        
        if (response.ok) {
          const data = await response.json();
          setSeatingArrangements(data);
          
          // Group by room for easy access
          const byRoom = {};
          for (const arr of data) {
            if (!byRoom[arr.roomId]) {
              byRoom[arr.roomId] = [];
            }
            byRoom[arr.roomId].push(arr);
          }
          
          setArrangementsByRoom(byRoom);
          showSnackbar('Seating arrangement generated successfully!', 'success');
          handleViewArrangement();
        } else if (response.status === 401) {
          navigate('/login');
        } else {
          const errorData = await response.json();
          showSnackbar(errorData.error || 'Failed to generate seating arrangement', 'error');
        }
      } else {
        // Multiple exams arrangement
        const payload = {
          examIds: selectedExams.map(exam => exam.id),
          roomIds: selectedRooms
        };
        
        const response = await fetch('http://localhost:8081/api/seating-arrangements/generate-multi', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${token}`
          },
          body: JSON.stringify(payload)
        });
        
        if (response.ok) {
          const data = await response.json();
          setSeatingArrangements(data);
          
          // Group by room for easy access
          const byRoom = {};
          for (const arr of data) {
            if (!byRoom[arr.roomId]) {
              byRoom[arr.roomId] = [];
            }
            byRoom[arr.roomId].push(arr);
          }
          
          setArrangementsByRoom(byRoom);
          showSnackbar('Multiple exam seating arrangement generated successfully!', 'success');
          handleViewArrangement();
        } else if (response.status === 401) {
          navigate('/login');
        } else {
          const errorData = await response.json();
          showSnackbar(errorData.error || 'Failed to generate seating arrangement', 'error');
        }
      }
    } catch (error) {
      console.error('Error generating seating arrangement:', error);
      showSnackbar('Error generating seating arrangement', 'error');
    } finally {
      setGenerateLoading(false);
    }
  };

  const handleViewArrangement = () => {
    setViewArrangementDialog(true);
  };

  const handlePrintArrangement = () => {
    const printContent = document.getElementById('print-area');
    if (!printContent) {
      console.error('Print area not found');
      return;
    }
    
    const winPrint = window.open('', '', 'left=0,top=0,width=800,height=900,toolbar=0,scrollbars=0,status=0');
    winPrint.document.write(`
      <html>
        <head>
          <title>Seating Arrangement</title>
          <style>
            body { font-family: Arial, sans-serif; }
            table { width: 100%; border-collapse: collapse; margin-bottom: 20px; }
            th, td { padding: 8px; text-align: left; border: 1px solid #ddd; }
            th { background-color: #f2f2f2; }
            .header { text-align: center; margin-bottom: 20px; }
            .set1 { background-color: #e3f2fd; }
            .set2 { background-color: #fff8e1; }
          </style>
        </head>
        <body>
          <div class="header">
            <h2>Seating Arrangement</h2>
          </div>
          ${printContent.innerHTML}
        </body>
      </html>
    `);
    
    winPrint.document.close();
    winPrint.focus();
    winPrint.print();
    winPrint.close();
  };
  
  const handleRoomSelect = (roomId) => {
    setSelectedRoomForView(roomId);
  };

  const showSnackbar = (message, severity) => {
    setSnackbarData({
      message,
      severity
    });
    setSnackbarOpen(true);
  };

  const handleSnackbarClose = (event, reason) => {
    if (reason === 'clickaway') {
      return;
    }
    setSnackbarOpen(false);
  };
  
  // Fixed exportToCSV function with proper try-catch structure
  const exportToCSV = () => {
    try {
      const arrangements = selectedRoomArrangements.length > 0 ? 
        selectedRoomArrangements : 
        seatingArrangements;
      
      if (!arrangements || arrangements.length === 0) {
        showSnackbar('No data to export', 'warning');
        return;
      }
      
      // Define CSV headers
      const headers = [
        'Room Number',
        'Seat Number',
        'Student Name',
        'Registration Number',
        'Section',
        'Subject',
        'Exam Name',
        'Set Type',
        'Row',
        'Column'
      ];
      
      // Convert data to CSV format
      const csvData = arrangements.map(arr => [
        arr.roomNumber,
        arr.seatNumber,
        arr.studentName,
        arr.registrationNumber,
        arr.sectionName,
        arr.subjectCode,
        arr.examName,
        arr.setType,
        arr.rowNumber,
        arr.columnNumber
      ]);
      
      // Add header row
      csvData.unshift(headers);
      
      // Convert to CSV string
      const csvContent = csvData.map(row => row.map(cell => 
        '"' + (cell ? cell.toString().replace(/"/g, '""') : '') + '"'
      ).join(',')).join('\n');
      
      // Create download link
      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.setAttribute('href', url);
      link.setAttribute('download', 'seating_arrangement_' + new Date().toISOString().slice(0,10) + '.csv');
      link.style.visibility = 'hidden';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (error) {
      console.error('Error exporting to CSV:', error);
      showSnackbar('Error exporting data', 'error');
    }
  };

  const handleOpenDeleteDialog = (exam) => {
    setExamToDelete(exam);
    setConfirmDeleteDialog(true);
  };

  const handleCloseDeleteDialog = () => {
    setConfirmDeleteDialog(false);
    setExamToDelete(null);
  };

  const deleteSeatingArrangement = async () => {
    if (!examToDelete) return;
    
    try {
      setDeleteLoading(true);
      const token = localStorage.getItem('token');
      
      const response = await fetch('http://localhost:8081/api/seating-arrangements/exam/' + examToDelete.id, {
        method: 'DELETE',
        headers: {
          'Authorization': 'Bearer ' + token
        }
      });
      
      if (response.ok) {
        showSnackbar('Seating arrangement deleted successfully', 'success');
        fetchExamsWithExistingArrangements();
        handleCloseDeleteDialog();
      } else if (response.status === 401) {
        navigate('/login');
      } else {
        const errorData = await response.json();
        showSnackbar(errorData.error || 'Failed to delete seating arrangement', 'error');
      }
    } catch (error) {
      console.error('Error deleting seating arrangement:', error);
      showSnackbar('Error deleting seating arrangement', 'error');
    } finally {
      setDeleteLoading(false);
    }
  };

  // Handle clicking on an exam with existing arrangements
  const handleExistingArrangementSelect = (exam) => {
    fetchExistingArrangements(exam.id);
    setSelectedExam(exam);
    setViewArrangementDialog(true);
  };

  // Modify the handleRoomArrangementSelect function to work with rooms instead of exams
  const handleRoomArrangementSelect = async (room) => {
    try {
      setRoomDetailsLoading(true);
      const token = localStorage.getItem('token');
      const response = await fetch(`http://localhost:8081/api/seating-arrangements/room/${room.roomId}`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      
      if (response.ok) {
        const data = await response.json();
        console.log("Room arrangements data:", data);
        
        setSelectedRoomDetails(room);
        setSelectedRoomArrangements(data);
        
        // Group by room for room view
        const byRoom = {};
        byRoom[room.roomId] = data;
        setArrangementsByRoom(byRoom);
        
        // Set selected room for view
        setSelectedRoomForView(room.roomId);
        
        // Open dialog to view arrangements
        setViewArrangementDialog(true);
      } else if (response.status === 401) {
        navigate('/login');
      } else {
        showSnackbar('Failed to fetch room arrangements', 'error');
      }
    } catch (error) {
      console.error('Error fetching room arrangements:', error);
      showSnackbar('Error fetching room arrangements', 'error');
    } finally {
      setRoomDetailsLoading(false);
    }
  };

  const handleDateChangeForRooms = (date) => {
    setSelectedDateForRooms(date);
    if (date) {
      fetchRoomsByDate(date);
    } else {
      setRoomsWithBookings([]);
    }
  };

  const filterRoomsByTime = (rooms) => {
    if (!rooms) return [];
    if (!timeFilterRange.start && !timeFilterRange.end) {
      return rooms;
    }
    
    return rooms.filter(room => {
      if (!room.exams || room.exams.length === 0) return false;
      
      return room.exams.some(exam => {
        if (!exam.startTime || !exam.endTime) return false;
        
        const examStart = exam.startTime;
        const examEnd = exam.endTime;
        
        if (timeFilterRange.start && !timeFilterRange.end) {
          return examEnd >= timeFilterRange.start;
        }
        
        if (!timeFilterRange.start && timeFilterRange.end) {
          return examStart <= timeFilterRange.end;
        }
        
        return (examStart <= timeFilterRange.end && examEnd >= timeFilterRange.start);
      });
    });
  };

  return (
    <Box sx={{ p: 3 }}>
      {/* Header */}
      <Typography 
        variant="h4" 
        sx={{ 
          textAlign: 'center', 
          color: '#1e3c72', 
          mb: 4,
          fontWeight: 'bold' 
        }}
      >
        Seating Arrangement Generator
      </Typography>

      {/* Tabs for switching between Generate and View Existing */}
      <Box sx={{ width: '100%', mb: 3 }}>
        <Tabs
          value={mainViewTab}
          onChange={(e, newValue) => setMainViewTab(newValue)}
          variant="fullWidth"
        >
          <Tab label="Generate New Arrangement" />
          <Tab label="View Existing Arrangements" />
        </Tabs>
      </Box>

      {mainViewTab === 0 ? (
        // Generate New Arrangement Tab - THIS IS WHAT NEEDS FIXING
        <Grid container spacing={3}>
          {/* Left column - Exam selection */}
          <Grid item xs={12} md={6}>
            <Paper sx={{ p: 3, boxShadow: 2, borderRadius: 2, height: '100%' }}>
              {/* Date selection */}
              <Box sx={{ mb: 3 }}>
                <Typography variant="h6" gutterBottom>Select Exam Date</Typography>
                <LocalizationProvider dateAdapter={AdapterDateFns}>
                  <DatePicker
                    value={selectedDate}
                    onChange={handleDateChange}
                    slotProps={{
                      textField: {
                        fullWidth: true,
                        size: "small"
                      }
                    }}
                  />
                </LocalizationProvider>
              </Box>

              {/* Exam list */}
              <Box sx={{ mb: 3 }}>
                <Typography variant="h6" gutterBottom>Select Exams</Typography>
                {examsLoading ? (
                  <Box sx={{ display: 'flex', justifyContent: 'center', p: 2 }}>
                    <CircularProgress />
                  </Box>
                ) : exams.length > 0 ? (
                  <TableContainer>
                    <Table size="small">
                      <TableHead>
                        <TableRow>
                          <TableCell padding="checkbox">Select</TableCell>
                          <TableCell>Exam</TableCell>
                          <TableCell>Subject</TableCell>
                          <TableCell>Time</TableCell>
                          <TableCell>Set Type</TableCell>
                        </TableRow>
                      </TableHead>
                      <TableBody>
                        {exams.map((exam) => (
                          <TableRow 
                            key={exam.id}
                            hover
                            onClick={() => handlePrimaryExamSelect(exam)}
                            selected={selectedExam?.id === exam.id}
                          >
                            <TableCell padding="checkbox">
                              <Checkbox
                                checked={selectedExams.some(e => e.id === exam.id)}
                                onChange={() => handleExamSelect(exam)}
                                color="primary"
                                disabled={examsWithArrangements[exam.id]}
                              />
                            </TableCell>
                            <TableCell>{exam.examName}</TableCell>
                            <TableCell>
                              <Typography variant="body2" fontWeight="bold">{exam.subjectCode}</Typography>
                              <Typography variant="body2" color="text.secondary">{exam.subjectName}</Typography>
                            </TableCell>
                            <TableCell>
                              <Typography variant="body2">{exam.startTime} - {exam.endTime}</Typography>
                            </TableCell>
                            <TableCell>
                              <Chip 
                                label={exam.setType} 
                                size="small" 
                                color={
                                  exam.setType === 'SET1' ? 'primary' : 
                                  exam.setType === 'SET2' ? 'secondary' : 
                                  'default'
                                }
                              />
                              {examsWithArrangements[exam.id] && (
                                <Chip 
                                  label="Exists" 
                                  size="small" 
                                  color="success"
                                  sx={{ ml: 1 }}
                                />
                              )}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </TableContainer>
                ) : selectedDate ? (
                  <Typography variant="body1" sx={{ textAlign: 'center', color: 'text.secondary', p: 2 }}>
                    No exams found for the selected date
                  </Typography>
                ) : (
                  <Typography variant="body1" sx={{ textAlign: 'center', color: 'text.secondary', p: 2 }}>
                    Please select a date first
                  </Typography>
                )}
              </Box>
            </Paper>
          </Grid>

          {/* Right column - Room selection */}
          <Grid item xs={12} md={6}>
            <Paper sx={{ p: 3, boxShadow: 2, borderRadius: 2, height: '100%' }}>
              <Box sx={{ mb: 3, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <Typography variant="h6">Available Rooms</Typography>
                <Box>
                  <FormControl size="small" sx={{ width: 120, mr: 1 }}>
                    <InputLabel id="block-filter-label">Block</InputLabel>
                    <Select
                      labelId="block-filter-label"
                      value={blockFilter}
                      label="Block"
                      onChange={(e) => setBlockFilter(e.target.value)}
                    >
                      <MenuItem value="all">All</MenuItem>
                      {getUniqueBlocks().map(block => (
                        <MenuItem key={block} value={block}>{block}</MenuItem>
                      ))}
                    </Select>
                  </FormControl>
                  <FormControl size="small" sx={{ width: 120 }}>
                    <InputLabel id="floor-filter-label">Floor</InputLabel>
                    <Select
                      labelId="floor-filter-label"
                      value={floorFilter}
                      label="Floor"
                      onChange={(e) => setFloorFilter(e.target.value)}
                    >
                      <MenuItem value="all">All</MenuItem>
                      {getUniqueFloors().map(floor => (
                        <MenuItem key={floor} value={floor}>{floor}</MenuItem>
                      ))}
                    </Select>
                  </FormControl>
                </Box>
              </Box>

              {roomsLoading ? (
                <Box sx={{ display: 'flex', justifyContent: 'center', p: 2 }}>
                  <CircularProgress />
                </Box>
              ) : availableRooms.length > 0 ? (
                <>
                  <Box sx={{ maxHeight: '400px', overflow: 'auto' }}>
                    <Grid container spacing={2}>
                      {getFilteredRooms().map(room => (
                        <Grid item xs={12} sm={6} key={room.roomId}>
                          <Card
                            sx={{
                              border: selectedRooms.includes(room.roomId) 
                                ? '2px solid #1e3c72' 
                                : '1px solid #e0e0e0',
                              cursor: room.isAvailable ? 'pointer' : 'not-allowed',
                              opacity: room.isAvailable ? 1 : 0.6,
                              backgroundColor: selectedRooms.includes(room.roomId) 
                                ? 'rgba(30, 60, 114, 0.1)' 
                                : 'white',
                              position: 'relative'
                            }}
                            onClick={() => {
                              if (room.isAvailable) {
                                handleRoomToggle(room.roomId);
                              }
                            }}
                          >
                            {!room.isAvailable && (
                              <Box 
                                sx={{ 
                                  position: 'absolute', 
                                  top: 0, 
                                  right: 0, 
                                  backgroundColor: 'error.main',
                                  color: 'white',
                                  px: 1,
                                  borderBottomLeftRadius: 4
                                }}
                              >
                                Occupied
                              </Box>
                            )}
                            <CardContent>
                              <Typography variant="h6">
                                Room {room.roomNumber}
                              </Typography>
                              <Typography variant="body2" color="text.secondary">
                                {room.blockName} Block, Floor {room.floorNumber}
                              </Typography>
                              <Typography variant="body2" mt={1}>
                                Capacity: {room.capacity} students
                              </Typography>
                              <Typography variant="body2">
                                Type: {room.roomType.replace('ROOM_', '').replace('_', ' × ')}
                              </Typography>
                            </CardContent>
                          </Card>
                        </Grid>
                      ))}
                    </Grid>
                  </Box>

                  <Box sx={{ mt: 3, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <Typography variant="subtitle1">
                      Selected Rooms: {selectedRooms.length}
                    </Typography>
                    <Button 
                      variant="contained" 
                      disabled={!selectedExams.length || !selectedRooms.length || generateLoading}
                      onClick={generateSeatingArrangement}
                      startIcon={generateLoading ? <CircularProgress size={20} color="inherit" /> : <EventSeatIcon />}
                      sx={buttonStyle}
                    >
                      {generateLoading ? 'Generating...' : 'Generate Seating'}
                    </Button>
                  </Box>
                </>
              ) : selectedExam ? (
                <Typography variant="body1" sx={{ textAlign: 'center', color: 'text.secondary', p: 2 }}>
                  No available rooms found
                </Typography>
              ) : (
                <Typography variant="body1" sx={{ textAlign: 'center', color: 'text.secondary', p: 2 }}>
                  Please select an exam first
                </Typography>
              )}
            </Paper>
          </Grid>
        </Grid>
      ) : (
        // View Existing Arrangements Tab
        <Paper sx={{ p: 3, boxShadow: 2, borderRadius: 2 }}>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
            <Typography variant="h6">Rooms with Seating Arrangements</Typography>
            <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
              <LocalizationProvider dateAdapter={AdapterDateFns}>
                <DatePicker
                  label="Select Date"
                  value={selectedDateForRooms}
                  onChange={handleDateChangeForRooms}
                  slotProps={{
                    textField: {
                      size: "small",
                      sx: { width: 200 }
                    }
                  }}
                />
              </LocalizationProvider>
              <Button 
                variant="contained"
                color="primary"
                startIcon={<RefreshIcon />}
                onClick={() => {
                  if (selectedDateForRooms) {
                    fetchRoomsByDate(selectedDateForRooms);
                  } else {
                    fetchRoomsWithArrangements();
                  }
                }}
                disabled={loadingRoomsByDate || loadingExistingArrangements}
              >
                Refresh
              </Button>
            </Box>
          </Box>

          {selectedDateForRooms ? (
            // Date-specific view
            loadingRoomsByDate ? (
              <Box sx={{ display: 'flex', justifyContent: 'center', py: 4 }}>
                <CircularProgress />
              </Box>
            ) : roomsWithBookings.length > 0 ? (
              <Grid container spacing={2}>
                {filterRoomsByTime(roomsWithBookings).map(room => (
                  <Grid item xs={12} sm={6} md={4} key={room.roomId}>
                    <Card 
                      sx={{ 
                        cursor: 'pointer',
                        transition: 'transform 0.2s ease',
                        '&:hover': { transform: 'translateY(-4px)', boxShadow: 3 }
                      }}
                      onClick={() => handleRoomArrangementSelect(room)}
                    >
                      <CardContent>
                        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 1 }}>
                          <Typography variant="h6" noWrap>
                            Room {room.roomNumber}
                          </Typography>
                          <Chip
                            color="primary"
                            label={`${room.studentCount} Students`}
                          />
                        </Box>
                        
                        <Typography variant="body2" color="text.secondary" gutterBottom>
                          {room.blockName} Block, Floor {room.floorNumber}
                        </Typography>
                        
                        {/* SET Types Display */}
                        {room.setTypes && room.setTypes.length > 0 && (
                          <Box sx={{ mt: 1, mb: 1 }}>
                            <Stack direction="row" spacing={1}>
                              {room.setTypes.includes('SET1') && (
                                <Chip 
                                  label="SET1" 
                                  size="small" 
                                  sx={{ bgcolor: '#e3f2fd', color: 'primary.dark' }} 
                                />
                              )}
                              {room.setTypes.includes('SET2') && (
                                <Chip 
                                  label="SET2" 
                                  size="small" 
                                  sx={{ bgcolor: '#fff8e1', color: '#ff9800' }}
                                />
                              )}
                            </Stack>
                          </Box>
                        )}
                        
                        <Divider sx={{ my: 1 }} />
                        
                        {/* Schedule Display */}
                        <Typography variant="subtitle2" sx={{ mb: 1 }}>
                          Schedule:
                        </Typography>
                        
                        {room.exams && room.exams.map((exam, index) => (
                          <Box key={index} sx={{ mb: 1, display: 'flex', alignItems: 'flex-start' }}>
                            <AccessTimeIcon sx={{ fontSize: 16, mr: 1, mt: 0.3, color: 'text.secondary' }} />
                            <Box>
                              <Typography variant="body2" sx={{ fontWeight: 500 }}>
                                {exam.startTime} - {exam.endTime}
                              </Typography>
                              <Typography variant="caption" color="text.secondary" noWrap>
                                {exam.examName}
                              </Typography>
                            </Box>
                          </Box>
                        ))}
                      </CardContent>
                    </Card>
                  </Grid>
                ))}
              </Grid>
            ) : (
              <Box sx={{ textAlign: 'center', py: 4, color: 'text.secondary' }}>
                <Typography variant="h6">No rooms found with seating arrangements for this date</Typography>
              </Box>
            )
          ) : (
            // All rooms view
            loadingExistingArrangements ? (
              <Box sx={{ display: 'flex', justifyContent: 'center', py: 4 }}>
                <CircularProgress />
              </Box>
            ) : roomsWithSeatingArrangements.length > 0 ? (
              <Grid container spacing={2}>
                {roomsWithSeatingArrangements.map(room => (
                  <Grid item xs={12} sm={6} md={4} key={room.roomId}>
                    <Card 
                      sx={{ 
                        cursor: 'pointer',
                        transition: 'transform 0.2s ease',
                        '&:hover': { transform: 'translateY(-4px)', boxShadow: 3 }
                      }}
                      onClick={() => handleRoomArrangementSelect(room)}
                    >
                      <CardContent>
                        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 1 }}>
                          <Typography variant="h6" noWrap>
                            Room {room.roomNumber}
                          </Typography>
                          <Chip
                            color="primary"
                            label={`${room.studentCount} Students`}
                          />
                        </Box>
                        
                        <Typography variant="body2" color="text.secondary" gutterBottom>
                          {room.blockName} Block, Floor {room.floorNumber}
                        </Typography>
                        
                        {/* SET Types Display */}
                        {room.setTypes && room.setTypes.length > 0 && (
                          <Box sx={{ mt: 1, mb: 1 }}>
                            <Stack direction="row" spacing={1}>
                              {room.setTypes.includes('SET1') && (
                                <Chip 
                                  label="SET1" 
                                  size="small" 
                                  sx={{ bgcolor: '#e3f2fd', color: 'primary.dark' }} 
                                />
                              )}
                              {room.setTypes.includes('SET2') && (
                                <Chip 
                                  label="SET2" 
                                  size="small" 
                                  sx={{ bgcolor: '#fff8e1', color: '#ff9800' }}
                                />
                              )}
                            </Stack>
                          </Box>
                        )}
                        
                        <Divider sx={{ my: 1 }} />
                        
                        <Typography variant="subtitle2" sx={{ mb: 1 }}>
                          Exams: {room.examCount || 0}
                        </Typography>
                        
                        <Button 
                          size="small" 
                          variant="outlined"
                          startIcon={<TableChartIcon />}
                          sx={{ mt: 1 }}
                        >
                          View Layout
                        </Button>
                      </CardContent>
                    </Card>
                  </Grid>
                ))}
              </Grid>
            ) : (
              <Box sx={{ textAlign: 'center', py: 4, color: 'text.secondary' }}>
                <Typography variant="h6">No rooms with seating arrangements found</Typography>
                <Typography variant="body1" sx={{ mt: 1 }}>
                  Generate new seating arrangements from the "Generate New Arrangement" tab.
                </Typography>
              </Box>
            )
          )}
        </Paper>
      )}

      {/* Seating Arrangement Dialog - For viewing arrangements */}
      <Dialog
        open={viewArrangementDialog}
        onClose={() => setViewArrangementDialog(false)}
        maxWidth="lg"
        fullWidth
      >
        <DialogTitle>
          <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <Typography variant="h6">
              {selectedRoomDetails ? 
                `Room ${selectedRoomDetails.roomNumber} - ${selectedRoomDetails.blockName} Block, Floor ${selectedRoomDetails.floorNumber}` : 
                "Seating Arrangement"}
            </Typography>
            <Box>
              <IconButton onClick={exportToCSV} title="Export to CSV">
                <DownloadIcon />
              </IconButton>
              <IconButton onClick={handlePrintArrangement} title="Print">
                <PrintIcon />
              </IconButton>
            </Box>
          </Box>
          <Typography variant="subtitle2" color="text.secondary">
            {selectedRoomArrangements.length > 0 ? 
              `Total Students: ${selectedRoomArrangements.length} | Exams: ${
                new Set(selectedRoomArrangements.map(a => a.examId)).size
              }` : 
              'No data available'}
          </Typography>
        </DialogTitle>
        <DialogContent dividers>
          <Tabs
            value={currentTab}
            onChange={(e, newValue) => setCurrentTab(newValue)}
            sx={{ mb: 2, borderBottom: 1, borderColor: 'divider' }}
          >
            <Tab label="All Students" />
            <Tab label="Room Layout" />
          </Tabs>
          
          {/* Tab 1: All Students View */}
          {currentTab === 0 && (
            <Box id="print-area">
              <Box sx={{ mb: 2, display: 'flex', gap: 2 }}>
                <Chip 
                  icon={<Box sx={{ bgcolor: '#e3f2fd', width: 12, height: 12, borderRadius: '50%' }}></Box>}
                  label="SET 1 Students"
                  sx={{ bgcolor: 'transparent', border: '1px solid #e3f2fd' }}
                />
                <Chip 
                  icon={<Box sx={{ bgcolor: '#fff8e1', width: 12, height: 12, borderRadius: '50%' }}></Box>}
                  label="SET 2 Students"
                  sx={{ bgcolor: 'transparent', border: '1px solid #fff8e1' }}
                />
              </Box>
              <TableContainer component={Paper} sx={{ mb: 2 }}>
                <Table size="small">
                  <TableHead>
                    <TableRow sx={{ bgcolor: '#f5f5f5' }}>
                      <TableCell>Seat No.</TableCell>
                      <TableCell>Reg. Number</TableCell>
                      <TableCell>Student Name</TableCell>
                      <TableCell>Section</TableCell>
                      <TableCell>Subject</TableCell>
                      <TableCell>Exam</TableCell>
                      <TableCell>Set</TableCell>
                      <TableCell>Row</TableCell>
                      <TableCell>Column</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {selectedRoomArrangements.length > 0 ? (
                      selectedRoomArrangements.map((arrangement) => (
                        <TableRow key={arrangement.id} hover sx={{
                          bgcolor: arrangement.setType === 'SET1' ? 'rgba(227, 242, 253, 0.3)' : 
                                  arrangement.setType === 'SET2' ? 'rgba(255, 248, 225, 0.3)' : 'transparent'
                        }}>
                          <TableCell>{arrangement.seatNumber}</TableCell>
                          <TableCell>{arrangement.registrationNumber}</TableCell>
                          <TableCell>{arrangement.studentName}</TableCell>
                          <TableCell>{arrangement.sectionName}</TableCell>
                          <TableCell>{arrangement.subjectCode}</TableCell>
                          <TableCell>{arrangement.examName}</TableCell>
                          <TableCell>
                            <Chip 
                              label={arrangement.setType}
                              size="small"
                              sx={{
                                bgcolor: arrangement.setType === 'SET1' ? '#e3f2fd' : 
                                        arrangement.setType === 'SET2' ? '#fff8e1' : 'default',
                                color: arrangement.setType === 'SET1' ? 'primary.dark' : 
                                       arrangement.setType === 'SET2' ? '#ff9800' : 'default'
                              }}
                            />
                          </TableCell>
                          <TableCell>{arrangement.rowNumber}</TableCell>
                          <TableCell>{arrangement.columnNumber}</TableCell>
                        </TableRow>
                      ))
                    ) : (
                      <TableRow>
                        <TableCell colSpan={9} align="center">
                          No seating arrangements available
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </TableContainer>
            </Box>
          )}
          
          {/* Tab 2: Room Layout View */}
          {currentTab === 1 && selectedRoomForView && (
            <Box>
              <Typography variant="h6" gutterBottom>
                Room Layout: {selectedRoomDetails?.roomNumber || 'Unknown Room'}
              </Typography>
              
              <Paper sx={{ p: 2, mb: 2 }}>
                {selectedRoomArrangements.length > 0 && (
                  <Grid container spacing={1}>
                    {(() => {
                      const maxRow = Math.max(...selectedRoomArrangements.map(a => a.rowNumber));
                      const maxCol = Math.max(...selectedRoomArrangements.map(a => a.columnNumber));
                      
                      // Create a 2D grid
                      const grid = Array(maxRow).fill().map(() => Array(maxCol).fill(null));
                      
                      // Fill grid with arrangements
                      selectedRoomArrangements.forEach(arr => {
                        if (arr.rowNumber > 0 && arr.columnNumber > 0 && 
                            arr.rowNumber <= maxRow && arr.columnNumber <= maxCol) {
                          grid[arr.rowNumber - 1][arr.columnNumber - 1] = arr;
                        }
                      });
                      
                      return (
                        <Box sx={{ 
                          display: 'flex', 
                          flexDirection: 'column',
                          alignItems: 'center',
                          width: '100%'
                        }}>
                          {grid.map((row, rowIndex) => (
                            <Box 
                              key={rowIndex} 
                              sx={{ 
                                display: 'flex',
                                width: '100%',
                                justifyContent: 'center',
                                mb: 1
                              }}
                            >
                              {row.map((seat, colIndex) => (
                                <Box 
                                  key={colIndex} 
                                  sx={{
                                    border: '1px solid #ccc',
                                    p: 1,
                                    m: 0.5,
                                    width: 150,
                                    height: 100,
                                    display: 'flex',
                                    flexDirection: 'column',
                                    justifyContent: 'center',
                                    alignItems: 'center',
                                    textAlign: 'center',
                                    bgcolor: seat?.setType === 'SET1' ? '#e3f2fd' : 
                                            seat?.setType === 'SET2' ? '#fff8e1' : 'white',
                                    opacity: seat ? 1 : 0.3
                                  }}
                                >
                                  {seat ? (
                                    <>
                                      <Typography variant="subtitle2" fontWeight="bold" noWrap>
                                        {seat.seatNumber}. {seat.registrationNumber}
                                      </Typography>
                                      <Typography variant="body2" noWrap>
                                        {seat.studentName}
                                      </Typography>
                                      <Typography variant="body2" color="text.secondary" noWrap>
                                        {seat.sectionName} | {seat.setType}
                                      </Typography>
                                    </>
                                  ) : (
                                    <Typography variant="body2" color="text.disabled">
                                      Empty
                                    </Typography>
                                  )}
                                </Box>
                              ))}
                            </Box>
                          ))}
                        </Box>
                      );
                    })()}
                  </Grid>
                )}
              </Paper>
              
              <Box sx={{ display: 'flex', justifyContent: 'flex-start', gap: 2, mb: 2 }}>
                <Box sx={{ display: 'flex', alignItems: 'center' }}>
                  <Box sx={{ bgcolor: '#e3f2fd', width: 20, height: 20, mr: 1 }} />
                  <Typography variant="body2">SET 1</Typography>
                </Box>
                <Box sx={{ display: 'flex', alignItems: 'center' }}>
                  <Box sx={{ bgcolor: '#fff8e1', width: 20, height: 20, mr: 1 }} />
                  <Typography variant="body2">SET 2</Typography>
                </Box>
              </Box>
            </Box>
          )}
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setViewArrangementDialog(false)} color="inherit">
            Close
          </Button>
        </DialogActions>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog
        open={confirmDeleteDialog}
        onClose={handleCloseDeleteDialog}
        aria-labelledby="delete-dialog-title"
      >
        <DialogTitle id="delete-dialog-title">Confirm Delete</DialogTitle>
        <DialogContent>
          <DialogContentText>
            Are you sure you want to delete the seating arrangement for exam: {examToDelete?.examName}?
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseDeleteDialog} color="inherit">
            Cancel
          </Button>
          <Button 
            onClick={deleteSeatingArrangement} 
            color="error" 
            disabled={deleteLoading}
            startIcon={deleteLoading && <CircularProgress size={20} />}
          >
            {deleteLoading ? 'Deleting...' : 'Delete'}
          </Button>
        </DialogActions>
      </Dialog>

      <Snackbar
        open={snackbarOpen}
        autoHideDuration={3000}
        onClose={handleSnackbarClose}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
      >
        <Alert 
          onClose={handleSnackbarClose} 
          severity={snackbarData.severity}
          variant="filled"
          sx={{ width: '100%' }}
        >
          {snackbarData.message}
        </Alert>
      </Snackbar>
    </Box>
  );
}

export default SeatingArrangement;
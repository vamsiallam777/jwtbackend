import React, { useState, useEffect } from 'react';
import { Routes, Route } from 'react-router-dom';
import Side from './side';
import Room from './Room';
import Student from './Student';
import StudentList from './StudentList';
import SectionList from './SectionList';
import Invigilator from './Invigilator';
import Subject from './Subject';
import Exam from './Exam';
import SeatingArrangement from './SeatingArrangement';
import './Dashboard.css';
import { 
  Typography, 
  Grid, 
  Card, 
  CardContent, 
  Box, 
  Button, 
  CircularProgress, 
  Paper,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogContentText,
  DialogActions,
  Snackbar,
  Alert
} from '@mui/material';
import { 
  School as SchoolIcon, 
  EventSeat as EventSeatIcon,
  MenuBook as MenuBookIcon,
  Event as EventIcon,
  Delete as DeleteIcon
} from '@mui/icons-material';

function Dashboard() {
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [dashboardData, setDashboardData] = useState({
    examsCount: 0,
    studentsCount: 0,
    subjectsCount: 0,
    arrangementsCount: 0,
    recentArrangements: []
  });
  const [loading, setLoading] = useState(true);
  const [confirmDeleteDialog, setConfirmDeleteDialog] = useState(false);
  const [arrangementToDelete, setArrangementToDelete] = useState(null);
  const [deleteLoading, setDeleteLoading] = useState(false);
  const [snackbarOpen, setSnackbarOpen] = useState(false);
  const [snackbarData, setSnackbarData] = useState({ message: '', severity: 'success' });

  useEffect(() => {
    // Fetch dashboard data when component mounts
    fetchDashboardData();
  }, []);

  const fetchDashboardData = async () => {
    try {
      setLoading(true);
      const token = localStorage.getItem('token');
      
      if (!token) {
        console.error('No authentication token found');
        return;
      }

      const headers = {
        'Authorization': `Bearer ${token}`,
        'Content-Type': 'application/json'
      };
      
      // Create safer fetch function that handles errors properly
      const safeFetch = async (url) => {
        try {
          const response = await fetch(url, { headers });
          
          if (!response.ok) {
            if (response.status === 401) {
              console.warn(`Authentication failed for ${url}`);
              return null;
            }
            console.warn(`Request failed for ${url}: ${response.status}`);
            return null;
          }
          
          const contentType = response.headers.get("content-type");
          if (contentType && contentType.indexOf("application/json") !== -1) {
            return await response.json();
          }
          
          console.warn(`Non-JSON response from ${url}`);
          return null;
        } catch (error) {
          console.error(`Error fetching ${url}:`, error);
          return null;
        }
      };
      
      // Make parallel requests for different entities
      const [examsData, studentsData, subjectsData, arrangementsData] = await Promise.all([
        safeFetch('http://localhost:8081/api/exams/count'),
        safeFetch('http://localhost:8081/api/students/count'),
        safeFetch('http://localhost:8081/api/subjects/count'),
        safeFetch('http://localhost:8081/api/seating-arrangements/count')
      ]);
      
      // Update state with whichever data is available
      setDashboardData({
        examsCount: examsData?.count || 0,
        studentsCount: studentsData?.count || 0,
        subjectsCount: subjectsData?.count || 0,
        arrangementsCount: arrangementsData?.count || 0,
        recentArrangements: arrangementsData?.recent || []
      });
    } catch (error) {
      console.error('Error fetching dashboard data:', error);
    } finally {
      setLoading(false);
    }
  };
  
  const handleOpenDeleteDialog = (arrangement, event) => {
    // Prevent navigating to details when clicking delete
    event.stopPropagation();
    setArrangementToDelete(arrangement);
    setConfirmDeleteDialog(true);
  };

  const handleCloseDeleteDialog = () => {
    setConfirmDeleteDialog(false);
    setArrangementToDelete(null);
  };

  const deleteSeatingArrangement = async () => {
    if (!arrangementToDelete) return;
    
    try {
      setDeleteLoading(true);
      const token = localStorage.getItem('token');
      
      const response = await fetch(`http://localhost:8081/api/seating-arrangements/exam/${arrangementToDelete.examId}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });
      
      if (response.ok) {
        // Refresh dashboard data
        fetchDashboardData();
        handleCloseDeleteDialog();
        showSnackbar('Seating arrangement deleted successfully', 'success');
      } else if (response.status === 401) {
        showSnackbar('Authentication failed. Please log in again.', 'error');
      } else {
        const errorData = await response.json();
        showSnackbar(errorData.error || 'Failed to delete seating arrangement', 'error');
      }
    } catch (error) {
      console.error('Error deleting seating arrangement:', error);
      showSnackbar('Error deleting seating arrangement', 'error');
    } finally {
      setDeleteLoading(false);
    }
  };

  const showSnackbar = (message, severity) => {
    setSnackbarData({
      message,
      severity
    });
    setSnackbarOpen(true);
  };

  const handleSnackbarClose = (event, reason) => {
    if (reason === 'clickaway') {
      return;
    }
    setSnackbarOpen(false);
  };
  
  const DashboardHome = () => (
    <div className="dashboard-home">
      <Typography variant="h4" sx={{ mb: 3, color: '#1e3c72', fontWeight: 'bold' }}>
        Dashboard Overview
      </Typography>
      
      {loading ? (
        <Box sx={{ display: 'flex', justifyContent: 'center', my: 4 }}>
          <CircularProgress />
        </Box>
      ) : (
        <>
          <Grid container spacing={3} sx={{ mb: 4 }}>
            <Grid item xs={12} sm={6} md={3}>
              <Card sx={{ 
                height: '100%', 
                boxShadow: 3, 
                bgcolor: '#e3f2fd',
                transition: 'transform 0.3s', 
                '&:hover': { transform: 'translateY(-5px)' } 
              }}>
                <CardContent sx={{ textAlign: 'center', py: 3 }}>
                  <SchoolIcon sx={{ fontSize: 48, color: '#1e3c72', mb: 2 }} />
                  <Typography variant="h4" sx={{ fontWeight: 'bold' }}>
                    {dashboardData?.studentsCount || 0}
                  </Typography>
                  <Typography variant="h6" color="text.secondary">Students</Typography>
                </CardContent>
              </Card>
            </Grid>
            
            <Grid item xs={12} sm={6} md={3}>
              <Card sx={{ 
                height: '100%', 
                boxShadow: 3, 
                bgcolor: '#fff8e1',
                transition: 'transform 0.3s', 
                '&:hover': { transform: 'translateY(-5px)' } 
              }}>
                <CardContent sx={{ textAlign: 'center', py: 3 }}>
                  <MenuBookIcon sx={{ fontSize: 48, color: '#ff9800', mb: 2 }} />
                  <Typography variant="h4" sx={{ fontWeight: 'bold' }}>
                    {dashboardData?.subjectsCount || 0}
                  </Typography>
                  <Typography variant="h6" color="text.secondary">Subjects</Typography>
                </CardContent>
              </Card>
            </Grid>
            
            <Grid item xs={12} sm={6} md={3}>
              <Card sx={{ 
                height: '100%', 
                boxShadow: 3, 
                bgcolor: '#e8f5e9',
                transition: 'transform 0.3s', 
                '&:hover': { transform: 'translateY(-5px)' } 
              }}>
                <CardContent sx={{ textAlign: 'center', py: 3 }}>
                  <EventIcon sx={{ fontSize: 48, color: '#2e7d32', mb: 2 }} />
                  <Typography variant="h4" sx={{ fontWeight: 'bold' }}>
                    {dashboardData?.examsCount || 0}
                  </Typography>
                  <Typography variant="h6" color="text.secondary">Exams</Typography>
                </CardContent>
              </Card>
            </Grid>
            
            <Grid item xs={12} sm={6} md={3}>
              <Card sx={{ 
                height: '100%', 
                boxShadow: 3, 
                bgcolor: '#fce4ec',
                transition: 'transform 0.3s', 
                '&:hover': { transform: 'translateY(-5px)' } 
              }}>
                <CardContent sx={{ textAlign: 'center', py: 3 }}>
                  <EventSeatIcon sx={{ fontSize: 48, color: '#c2185b', mb: 2 }} />
                  <Typography variant="h4" sx={{ fontWeight: 'bold' }}>
                    {dashboardData?.arrangementsCount || 0}
                  </Typography>
                  <Typography variant="h6" color="text.secondary">Seating Arrangements</Typography>
                </CardContent>
              </Card>
            </Grid>
          </Grid>
          
          <Typography variant="h5" sx={{ mb: 3, color: '#1e3c72' }}>
            Seating Arrangements
          </Typography>
          
          <Paper sx={{ p: 3, boxShadow: 2 }}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
              <Typography variant="h6">Recent Seating Arrangements</Typography>
              <Button 
                variant="contained" 
                color="primary" 
                onClick={() => window.location.href = '/seating-arrangement'}
                startIcon={<EventSeatIcon />}
              >
                Manage Arrangements
              </Button>
            </Box>
            
            {dashboardData?.recentArrangements?.length > 0 ? (
              <Grid container spacing={2}>
                {dashboardData.recentArrangements.map((arrangement) => (
                  <Grid item xs={12} md={6} lg={4} key={arrangement.examId}>
                    <Card sx={{ boxShadow: 2 }}>
                      <CardContent>
                        <Typography variant="h6">{arrangement.examName}</Typography>
                        <Typography variant="body2" color="text.secondary">
                          Date: {new Date(arrangement.examDate).toLocaleDateString()}
                        </Typography>
                        <Typography variant="body2">
                          Subject: {arrangement.subjectCode} - {arrangement.subjectName}
                        </Typography>
                        <Typography variant="body2">
                          Students: {arrangement.studentCount}
                        </Typography>
                        <Box sx={{ mt: 2, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                          <Button 
                            size="small" 
                            color="primary"
                            onClick={() => window.location.href = `/seating-arrangement?examId=${arrangement.examId}`}
                          >
                            View Details
                          </Button>
                          <Button 
                            size="small" 
                            color="error"
                            startIcon={<DeleteIcon />}
                            onClick={(e) => handleOpenDeleteDialog(arrangement, e)}
                          >
                            Delete
                          </Button>
                        </Box>
                      </CardContent>
                    </Card>
                  </Grid>
                ))}
              </Grid>
            ) : (
              <Typography variant="body1" sx={{ textAlign: 'center', py: 3 }}>
                No seating arrangements found. Create one from the Seating Arrangement page.
              </Typography>
            )}
          </Paper>
        </>
      )}
    </div>
  );
  
  return (
    <div className="dashboard-container">
      <Side onSidebarToggle={setIsSidebarOpen} />
      
      <main className={`dashboard-content ${isSidebarOpen ? 'sidebar-open' : 'sidebar-closed'}`}>
        <Routes>
          <Route path="/" element={<DashboardHome />} />
          <Route path="/dashboard" element={<DashboardHome />} />
          <Route path="/rooms" element={<Room />} />
          <Route path="/students" element={<Student />} />
          <Route path="/sections/branch/:branchId" element={<SectionList />} />
          <Route path="/invigilators" element={<Invigilator />} />
          <Route path="/subjects" element={<Subject />} />
          <Route path="/exams" element={<Exam />} />
          <Route path="/seating-arrangement" element={<SeatingArrangement />} />
        </Routes>
        
        {/* Add Confirmation Dialog for Delete */}
        <Dialog
          open={confirmDeleteDialog}
          onClose={handleCloseDeleteDialog}
        >
          <DialogTitle>Confirm Delete</DialogTitle>
          <DialogContent>
            <DialogContentText>
              Are you sure you want to delete the seating arrangement for exam: {arrangementToDelete?.examName}?
            </DialogContentText>
          </DialogContent>
          <DialogActions>
            <Button onClick={handleCloseDeleteDialog} color="inherit">
              Cancel
            </Button>
            <Button 
              onClick={deleteSeatingArrangement} 
              color="error" 
              disabled={deleteLoading}
              startIcon={deleteLoading && <CircularProgress size={20} />}
            >
              {deleteLoading ? 'Deleting...' : 'Delete'}
            </Button>
          </DialogActions>
        </Dialog>

        {/* Add Snackbar if it doesn't exist */}
        {!snackbarOpen && (
          <Snackbar
            open={snackbarOpen}
            autoHideDuration={3000}
            onClose={handleSnackbarClose}
            anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
          >
            <Alert 
              onClose={handleSnackbarClose} 
              severity={snackbarData.severity}
              variant="filled"
              sx={{ width: '100%' }}
            >
              {snackbarData.message}
            </Alert>
          </Snackbar>
        )}
      </main>
    </div>
  );
}

export default Dashboard;
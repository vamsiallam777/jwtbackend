package com.example.seating;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SeatingApplicationTests {

	@Test
	void contextLoads() {
	}

}

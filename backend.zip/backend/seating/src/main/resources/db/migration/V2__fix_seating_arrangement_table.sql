-- Drop and recreate seating_arrangement table with proper column names
DROP TABLE IF EXISTS seating_arrangement;

CREATE TABLE seating_arrangement (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  exam_id BIGINT NOT NULL,
  room_id BIGINT NOT NULL,
  seat_number INT NOT NULL,
  row_num INT NOT NULL,
  column_num INT NOT NULL,
  student_id VARCHAR(255) NOT NULL,
  student_name VARCHAR(255) NOT NULL,
  registration_number VARCHAR(255) NOT NULL,
  section_name VARCHAR(255) NOT NULL,
  set_type VARCHAR(50) NOT NULL,
  exam_date DATE NOT NULL,
  subject_code VARCHAR(100),
  subject_name VARCHAR(255),
  FOREIGN KEY (exam_id) REFERENCES exam(id),
  FOREIGN KEY (room_id) REFERENCES room(id)
);

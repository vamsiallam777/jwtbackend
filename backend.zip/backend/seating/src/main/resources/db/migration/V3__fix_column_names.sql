-- Drop the existing table if it exists
DROP TABLE IF EXISTS seating_arrangement;

-- Create the table with proper column names
CREATE TABLE seating_arrangement (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  exam_id BIGINT NOT NULL,
  room_id BIGINT NOT NULL,
  seat_number INT NOT NULL,
  row_num INT NOT NULL,
  column_num INT NOT NULL,
  student_id VARCHAR(255) NOT NULL,
  student_name VARCHAR(255) NOT NULL,
  registration_number VARCHAR(255) NOT NULL,
  section_name VARCHAR(255) NOT NULL,
  set_type VARCHAR(10) NOT NULL DEFAULT 'NO_SET',
  exam_date DATE NULL,
  subject_code VARCHAR(20) NULL,
  subject_name VARCHAR(255) NULL,
  FOREIGN KEY (exam_id) REFERENCES exam(id),
  FOREIGN KEY (room_id) REFERENCES room(id)
);

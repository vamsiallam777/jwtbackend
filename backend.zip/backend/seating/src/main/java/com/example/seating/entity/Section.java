package com.example.seating.entity;

import jakarta.persistence.*;
import lombok.*;

import java.util.List;

@Entity
@Table(name = "section")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Section {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(nullable = false)
    private String sectionName;
    
    @Column(nullable = true)
    private String formattedName;
    
    @Column(nullable = true)
    private Integer capacity;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "branch_id")
    private Branch branch;
    
    @Column(name = "branch_id", insertable = false, updatable = false)
    private Long branchId;
    
    @OneToMany(mappedBy = "section", cascade = CascadeType.ALL)
    private List<Student> students;
}
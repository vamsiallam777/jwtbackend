package com.example.seating.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.stream.Collectors;

@Component
public class ManualDatabaseFix implements CommandLineRunner {

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Override
    public void run(String... args) throws Exception {
        // Read the SQL script
        ClassPathResource resource = new ClassPathResource("db/manual_fix.sql");
        String sql = new BufferedReader(
                new InputStreamReader(resource.getInputStream(), StandardCharsets.UTF_8))
                .lines()
                .collect(Collectors.joining("\n"));
        
        // Execute the SQL statements
        for (String statement : sql.split(";")) {
            if (!statement.trim().isEmpty()) {
                System.out.println("Executing SQL: " + statement);
                jdbcTemplate.execute(statement);
            }
        }
    }
}

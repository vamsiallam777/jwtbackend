package com.example.seating.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.seating.repository.ExamRepository;
import com.example.seating.repository.StudentRepository;
import com.example.seating.repository.SubjectRepository;
import com.example.seating.service.SeatingArrangementService;

import lombok.RequiredArgsConstructor;
import java.util.Map;

@RestController
@RequestMapping("/api")
@CrossOrigin("*")
@RequiredArgsConstructor
public class DashboardController {
    
    private final StudentRepository studentRepository;
    private final SubjectRepository subjectRepository;
    private final ExamRepository examRepository;
    private final SeatingArrangementService seatingArrangementService;
    
    @GetMapping("/students/count")
    public ResponseEntity<Map<String, Object>> getStudentCount() {
        long count = studentRepository.count();
        return ResponseEntity.ok(Map.of("count", count));
    }
    
    @GetMapping("/subjects/count")
    public ResponseEntity<Map<String, Object>> getSubjectCount() {
        long count = subjectRepository.count();
        return ResponseEntity.ok(Map.of("count", count));
    }
    
    @GetMapping("/exams/count")
    public ResponseEntity<Map<String, Object>> getExamCount() {
        long count = examRepository.count();
        return ResponseEntity.ok(Map.of("count", count));
    }
}

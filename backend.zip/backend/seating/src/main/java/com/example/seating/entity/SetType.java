package com.example.seating.entity;

public enum SetType {
    NO_SET,
    SET1,
    SET2
}
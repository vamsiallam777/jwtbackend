package com.example.seating.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SeatingArrangementDTO {
    private Long id;
    private Long examId;
    private Long roomId;
    private String roomNumber;
    private String blockName;
    private Integer floorNumber;
    private Integer seatNumber;
    private Integer rowNumber;
    private Integer columnNumber;
    private String studentId;
    private String studentName;
    private String registrationNumber;
    private String sectionName;
    private String setType;
    private LocalDate examDate;
    private String examName;
    private String subjectCode;
    private String subjectName;
}

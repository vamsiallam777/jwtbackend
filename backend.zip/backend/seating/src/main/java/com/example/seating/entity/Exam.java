package com.example.seating.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Entity
@Table(name = "exam")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Exam {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(nullable = false)
    private String examName;
    
    @Column(nullable = false)
    private LocalDate examDate;
    
    @Column(nullable = false)
    private String startTime;
    
    @Column(nullable = false)
    private String endTime;
    
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private ExamType examType;
    
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private SetType setType;
    
    @ManyToOne
    @JoinColumn(name = "subject_id")
    private Subject subject;
    
    @ManyToOne
    @JoinColumn(name = "program_id")
    private Program program;
    
    @ManyToOne
    @JoinColumn(name = "year_id")
    private Year year;
    
    @ManyToMany
    @JoinTable(
        name = "exam_branch",
        joinColumns = @JoinColumn(name = "exam_id"),
        inverseJoinColumns = @JoinColumn(name = "branch_id")
    )
    private Set<Branch> branches = new HashSet<>();
    
    @ManyToMany
    @JoinTable(
        name = "exam_section",
        joinColumns = @JoinColumn(name = "exam_id"),
        inverseJoinColumns = @JoinColumn(name = "section_id")
    )
    private Set<Section> sections = new HashSet<>();
    
    // Helper methods to get IDs for easier access in services
    public Long getSubjectId() {
        return subject != null ? subject.getId() : null;
    }
    
    public Long getProgramId() {
        return program != null ? program.getId() : null;
    }
    
    public Long getYearId() {
        return year != null ? year.getId() : null;
    }
    
    public List<Long> getSectionIds() {
        return sections.stream().map(Section::getId).toList();
    }
    
    public List<Long> getBranchIds() {
        return branches.stream().map(Branch::getId).toList();
    }
}
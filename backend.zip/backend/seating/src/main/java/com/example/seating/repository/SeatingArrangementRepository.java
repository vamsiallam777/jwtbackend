package com.example.seating.repository;

import com.example.seating.entity.SeatingArrangement;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface SeatingArrangementRepository extends JpaRepository<SeatingArrangement, Long> {
    List<SeatingArrangement> findByExamId(Long examId);
    
    List<SeatingArrangement> findByExamIdAndRoomId(Long examId, Long roomId);
    
    void deleteByExamId(Long examId);
    
    boolean existsByExamId(Long examId);
    
    long countByExamId(Long examId);
    
    @Query("SELECT DISTINCT s.exam.id FROM SeatingArrangement s")
    List<Long> findExamsWithArrangements();
    
    List<SeatingArrangement> findByRoomId(Long roomId);
    
    @Query("SELECT sa.room.id, sa.room.roomNumber, b.name, f.floorNumber, " +
           "COUNT(DISTINCT sa.exam.id), COUNT(sa.id) " +
           "FROM SeatingArrangement sa " +
           "JOIN sa.room r " +
           "JOIN r.floor f " +
           "JOIN f.block b " +
           "GROUP BY sa.room.id, sa.room.roomNumber, b.name, f.floorNumber " +
           "ORDER BY b.name, f.floorNumber, sa.room.roomNumber")
    List<Object[]> findRoomsWithArrangements();
    
    @Query("SELECT sa.room.id, sa.room.roomNumber, b.name, f.floorNumber, " +
           "sa.exam.id, sa.exam.examName, sa.exam.startTime, sa.exam.endTime, COUNT(sa.id) " +
           "FROM SeatingArrangement sa " +
           "JOIN sa.room r " +
           "JOIN r.floor f " +
           "JOIN f.block b " +
           "WHERE sa.examDate = :date " +
           "GROUP BY sa.room.id, sa.room.roomNumber, b.name, f.floorNumber, " +
           "sa.exam.id, sa.exam.examName, sa.exam.startTime, sa.exam.endTime " +
           "ORDER BY b.name, f.floorNumber, sa.room.roomNumber, sa.exam.startTime")
    List<Object[]> findRoomsWithArrangementsByDate(@Param("date") LocalDate date);
    
    @Query("SELECT COUNT(DISTINCT sa.studentId) FROM SeatingArrangement sa WHERE sa.room.id = :roomId AND sa.examDate = :date")
    Long countStudentsByRoomIdAndDate(@Param("roomId") Long roomId, @Param("date") LocalDate date);
    
    @Query("SELECT DISTINCT sa.setType FROM SeatingArrangement sa WHERE sa.room.id = :roomId")
    List<String> findSetTypesByRoomId(@Param("roomId") Long roomId);
}

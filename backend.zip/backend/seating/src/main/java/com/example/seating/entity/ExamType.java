package com.example.seating.entity;

public enum ExamType {
    MIDTERM,
    SEMESTER
}
package com.example.seating.dto;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor

public class LoginRequest {
    public String email;
    public String phoneNumber;
    public String password;

    
}

package com.example.seating.dto;
import com.example.seating.entity.Role;

import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class RegisterRequest {
    private String name;
    private String email;
    private String phonenumber;
    private String password;
    private Role role;
}
package com.example.seating.service;

import com.example.seating.dto.RoomAvailabilityDTO;
import com.example.seating.dto.SeatingArrangementDTO;
import com.example.seating.dto.SeatingGenerationRequest;
import com.example.seating.dto.SeatingGenerationMultiRequest;
import com.example.seating.entity.*;
import com.example.seating.repository.*;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class SeatingArrangementService {
    private final ExamRepository examRepository;
    private final RoomRepository roomRepository;
    private final StudentRepository studentRepository;
    private final SectionRepository sectionRepository;
    private final SeatingArrangementRepository seatingArrangementRepository;
    private final BlockRepository blockRepository;
    private final FloorRepository floorRepository;
    private final SubjectRepository subjectRepository;

    public List<Exam> getExamsByDate(LocalDate date) {
        return examRepository.findByExamDate(date);
    }

    public List<RoomAvailabilityDTO> getAvailableRooms(Long examId) {
        Exam exam = examRepository.findById(examId)
                .orElseThrow(() -> new RuntimeException("Exam not found"));
        
        // Get all rooms
        List<Room> allRooms = roomRepository.findAll();
        
        // Get occupied room IDs for this date and time
        List<Long> occupiedRoomIds = findOccupiedRoomIds(exam);
        
        return allRooms.stream()
                .map(room -> {
                    Block block = room.getFloor().getBlock();
                    Floor floor = room.getFloor();
                    
                    return RoomAvailabilityDTO.builder()
                            .roomId(room.getId())
                            .roomNumber(room.getRoomNumber())
                            .blockName(block.getName())
                            .floorNumber(floor.getFloorNumber())
                            .capacity(room.getCapacity())
                            .roomType(room.getRoomType().toString())
                            .isAvailable(!occupiedRoomIds.contains(room.getId()))
                            .build();
                })
                .collect(Collectors.toList());
    }

    private List<Long> findOccupiedRoomIds(Exam exam) {
        LocalTime examStartTime = LocalTime.parse(exam.getStartTime());
        LocalTime examEndTime = LocalTime.parse(exam.getEndTime());
        
        // Find all exams on the same date
        List<Exam> sameDataExams = examRepository.findByExamDate(exam.getExamDate());
        
        // Filter exams with overlapping time
        List<Exam> overlappingExams = sameDataExams.stream()
                .filter(e -> {
                    if (e.getId().equals(exam.getId())) {
                        return false; // Skip the current exam
                    }
                    
                    LocalTime otherStartTime = LocalTime.parse(e.getStartTime());
                    LocalTime otherEndTime = LocalTime.parse(e.getEndTime());
                    
                    // Check if times overlap
                    return !(examEndTime.isBefore(otherStartTime) || examStartTime.isAfter(otherEndTime));
                })
                .collect(Collectors.toList());
        
        // Get all seating arrangements for overlapping exams
        List<Long> occupiedRoomIds = new ArrayList<>();
        for (Exam overlappingExam : overlappingExams) {
            List<SeatingArrangement> arrangements = seatingArrangementRepository.findByExamId(overlappingExam.getId());
            for (SeatingArrangement arrangement : arrangements) {
                if (!occupiedRoomIds.contains(arrangement.getRoom().getId())) {
                    occupiedRoomIds.add(arrangement.getRoom().getId());
                }
            }
        }
        
        return occupiedRoomIds;
    }

    @Transactional
    public List<SeatingArrangementDTO> generateSeatingArrangement(SeatingGenerationRequest request) {
        Long examId = request.getExamId();
        List<Long> roomIds = request.getRoomIds();
        
        // Clear any existing seating arrangements for this exam
        seatingArrangementRepository.deleteByExamId(examId);
        
        Exam exam = examRepository.findById(examId)
                .orElseThrow(() -> new RuntimeException("Exam not found"));
        
        // Get the subject directly from the exam entity
        Subject subject = exam.getSubject();
        if (subject == null) {
            throw new RuntimeException("Subject not found for exam");
        }
        
        // Get all students for the sections in the exam
        List<Student> allStudents = new ArrayList<>();
        for (Section section : exam.getSections()) {
            List<Student> sectionStudents = studentRepository.findBySectionId(section.getId());
            allStudents.addAll(sectionStudents);
        }
        
        // Shuffle students to randomize initial order
        Collections.shuffle(allStudents);
        
        // Sort students by section and set type for better organization
        Map<String, List<Student>> studentsBySection = new HashMap<>();
        for (Student student : allStudents) {
            // Get section name - handle the case where section might be null
            String sectionName;
            if (student.getSection() != null) {
                sectionName = student.getSection().getFormattedName() != null ? 
                        student.getSection().getFormattedName() : 
                        student.getSection().getSectionName();
            } else {
                // Fetch section from repository if not loaded with student
                Section section = sectionRepository.findById(student.getSectionId())
                        .orElseThrow(() -> new RuntimeException("Section not found for student: " + student.getId()));
                sectionName = section.getFormattedName() != null ? section.getFormattedName() : section.getSectionName();
            }
            
            // Add student to the section list
            studentsBySection.computeIfAbsent(sectionName, k -> new ArrayList<>()).add(student);
        }
        
        // Get all selected rooms
        List<Room> selectedRooms = roomRepository.findAllById(roomIds);
        
        // Generate seating arrangements
        List<SeatingArrangement> arrangements = generateArrangements(exam, selectedRooms, studentsBySection, subject);
        
        // Save all arrangements
        seatingArrangementRepository.saveAll(arrangements);
        
        // Convert to DTOs and return
        return arrangements.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    private List<SeatingArrangement> generateArrangements(Exam exam, List<Room> rooms, Map<String, List<Student>> studentsBySection, Subject subject) {
        List<SeatingArrangement> arrangements = new ArrayList<>();
        
        // Get set type from the exam
        String examSetType = exam.getSetType().toString();
        
        // Create a single list of all students to ensure we use them all
        List<Map.Entry<String, Student>> allStudents = new ArrayList<>();
        
        // Fill the list with all students from all sections
        for (Map.Entry<String, List<Student>> entry : studentsBySection.entrySet()) {
            String sectionName = entry.getKey();
            List<Student> students = entry.getValue();
            
            for (Student student : students) {
                allStudents.add(Map.entry(sectionName, student));
            }
        }
        
        // Shuffle all students for randomization
        Collections.shuffle(allStudents);
        
        // Initialize lists for each set type
        List<Map.Entry<String, Student>> set1Students = new ArrayList<>();
        List<Map.Entry<String, Student>> set2Students = new ArrayList<>();
        
        // Distribute students based on exam set type
        if (examSetType.equals("SET1")) {
            // All students are SET1
            set1Students.addAll(allStudents);
        } else if (examSetType.equals("SET2")) {
            // All students are SET2
            set2Students.addAll(allStudents);
        } else {
            // For NO_SET, distribute students evenly between SET1 and SET2
            for (int i = 0; i < allStudents.size(); i++) {
                if (i % 2 == 0) {
                    set1Students.add(allStudents.get(i));
                } else {
                    set2Students.add(allStudents.get(i));
                }
            }
        }
        
        // Process each room
        int overallSeatNumber = 1; // Global seat counter across all rooms
        
        for (Room room : rooms) {
            int rowCount = room.getRowCount();
            int colCount = room.getColumnCount();
            
            // Loop through each seat in the room
            for (int row = 1; row <= rowCount; row++) {
                for (int col = 1; col <= colCount; col++) {
                    // Determine which student to assign based on set type and seat position
                    Map.Entry<String, Student> studentEntry = null;
                    String setType = "";
                    
                    if (examSetType.equals("SET1")) {
                        // If all students are SET1, just take the next one
                        if (!set1Students.isEmpty()) {
                            studentEntry = set1Students.remove(0);
                            setType = "SET1";
                        }
                    } else if (examSetType.equals("SET2")) {
                        // If all students are SET2, just take the next one
                        if (!set2Students.isEmpty()) {
                            studentEntry = set2Students.remove(0);
                            setType = "SET2";
                        }
                    } else {
                        // For alternating sets (NO_SET case)
                        if (col % 2 == 1) { // Odd columns get SET1
                            if (!set1Students.isEmpty()) {
                                studentEntry = set1Students.remove(0);
                                setType = "SET1";
                            } else if (!set2Students.isEmpty()) {
                                // If SET1 is empty but SET2 isn't, use SET2
                                studentEntry = set2Students.remove(0);
                                setType = "SET2";
                            }
                        } else { // Even columns get SET2
                            if (!set2Students.isEmpty()) {
                                studentEntry = set2Students.remove(0);
                                setType = "SET2";
                            } else if (!set1Students.isEmpty()) {
                                // If SET2 is empty but SET1 isn't, use SET1
                                studentEntry = set1Students.remove(0);
                                setType = "SET1";
                            }
                        }
                    }
                    
                    // Skip this seat if no more students
                    if (studentEntry == null) {
                        continue;
                    }
                    
                    // Get student and section info
                    String sectionName = studentEntry.getKey();
                    Student student = studentEntry.getValue();
                    
                    // Create seating arrangement
                    SeatingArrangement arrangement = SeatingArrangement.builder()
                            .exam(exam)
                            .room(room)
                            .seatNumber(overallSeatNumber++)
                            .rowNumber(row)     // This maps to the renamed column row_num
                            .columnNumber(col)  // This maps to column_num
                            .studentId(student.getId().toString())
                            .studentName(student.getName())
                            .registrationNumber(student.getRegistrationNumber())
                            .sectionName(sectionName)
                            .setType(setType)  // Use the determined set type
                            .examDate(exam.getExamDate())
                            .subjectCode(subject.getCode())
                            .subjectName(subject.getName())
                            .build();
                    
                    arrangements.add(arrangement);
                }
            }
        }
        
        return arrangements;
    }

    @Transactional
    public List<SeatingArrangementDTO> generateMultiExamSeatingArrangement(SeatingGenerationMultiRequest request) {
        if (request.getExamIds() == null || request.getExamIds().isEmpty()) {
            throw new RuntimeException("No exam IDs provided");
        }
        if (request.getRoomIds() == null || request.getRoomIds().isEmpty()) {
            throw new RuntimeException("No room IDs provided");
        }
        
        List<Long> examIds = request.getExamIds();
        List<Long> roomIds = request.getRoomIds();
        
        // Clear any existing seating arrangements for these exams
        for (Long examId : examIds) {
            seatingArrangementRepository.deleteByExamId(examId);
        }
        
        // Get exams data
        List<Exam> exams = examRepository.findAllById(examIds);
        if (exams.isEmpty()) {
            throw new RuntimeException("No exams found with the provided IDs");
        }
        
        // Get all selected rooms
        List<Room> selectedRooms = roomRepository.findAllById(roomIds);
        if (selectedRooms.isEmpty()) {
            throw new RuntimeException("No rooms found with the provided IDs");
        }
        
        // Collect students from all exams and organize by set type
        Map<String, List<StudentExamInfo>> studentsBySetType = new HashMap<>();
        
        for (Exam exam : exams) {
            String setType = exam.getSetType().toString();
            
            // Get subject info
            Subject subject = exam.getSubject();
            if (subject == null) {
                throw new RuntimeException("Subject not found for exam: " + exam.getId());
            }
            
            for (Section section : exam.getSections()) {
                List<Student> sectionStudents = studentRepository.findBySectionId(section.getId());
                String sectionName = section.getFormattedName() != null ? 
                        section.getFormattedName() : section.getSectionName();
                
                for (Student student : sectionStudents) {
                    StudentExamInfo info = new StudentExamInfo(
                        student,
                        sectionName,
                        exam,
                        subject
                    );
                    
                    studentsBySetType.computeIfAbsent(setType, k -> new ArrayList<>()).add(info);
                }
            }
        }
        
        // Shuffle each set type for randomization
        for (List<StudentExamInfo> students : studentsBySetType.values()) {
            if (students != null) {
                Collections.shuffle(students);
            }
        }
        
        // Generate seating arrangements with alternating sets
        List<SeatingArrangement> arrangements = generateMultiExamArrangements(
            selectedRooms, studentsBySetType);
        
        if (arrangements.isEmpty()) {
            return Collections.emptyList();
        }
        
        // Save all arrangements
        seatingArrangementRepository.saveAll(arrangements);
        
        // Convert to DTOs and return
        return arrangements.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    private List<SeatingArrangement> generateMultiExamArrangements(
            List<Room> rooms, 
            Map<String, List<StudentExamInfo>> studentsBySetType) {
        List<SeatingArrangement> arrangements = new ArrayList<>();
        
        // Create queues of students by set type
        Queue<StudentExamInfo> set1Queue = new LinkedList<>(
            Optional.ofNullable(studentsBySetType.get("SET1")).orElse(Collections.emptyList())
        );
        Queue<StudentExamInfo> set2Queue = new LinkedList<>(
            Optional.ofNullable(studentsBySetType.get("SET2")).orElse(Collections.emptyList())
        );
        
        // Create a queue for NO_SET students and distribute them evenly
        List<StudentExamInfo> noSetStudents = 
            Optional.ofNullable(studentsBySetType.get("NO_SET")).orElse(Collections.emptyList());
        
        for (int i = 0; i < noSetStudents.size(); i++) {
            if (i % 2 == 0) {
                set1Queue.add(noSetStudents.get(i));
            } else {
                set2Queue.add(noSetStudents.get(i));
            }
        }
        
        // If one queue is empty but the other isn't, redistribute to balance
        if (set1Queue.isEmpty() && !set2Queue.isEmpty()) {
            List<StudentExamInfo> set2List = new ArrayList<>(set2Queue);
            set2Queue.clear();
            
            for (int i = 0; i < set2List.size(); i++) {
                if (i % 2 == 0) {
                    set1Queue.add(set2List.get(i));
                } else {
                    set2Queue.add(set2List.get(i));
                }
            }
        } else if (set2Queue.isEmpty() && !set1Queue.isEmpty()) {
            List<StudentExamInfo> set1List = new ArrayList<>(set1Queue);
            set1Queue.clear();
            
            for (int i = 0; i < set1List.size(); i++) {
                if (i % 2 == 0) {
                    set1Queue.add(set1List.get(i));
                } else {
                    set2Queue.add(set1List.get(i));
                }
            }
        }
        
        // If both queues are empty, return empty arrangement list
        if (set1Queue.isEmpty() && set2Queue.isEmpty()) {
            return Collections.emptyList();
        }
        
        // Process each room
        int overallSeatNumber = 1; // Global seat counter across all rooms
        
        for (Room room : rooms) {
            int rowCount = room.getRowCount();
            int colCount = room.getColumnCount();
            
            // Loop through each seat in the room
            for (int row = 1; row <= rowCount; row++) {
                for (int col = 1; col <= colCount; col++) {
                    // Determine which set to use for this column
                    StudentExamInfo studentInfo = null;
                    String setType;
                    
                    // Check if the exam is SET1 or SET2 specific, or alternating sets
                    if (!set1Queue.isEmpty() && !set2Queue.isEmpty()) {
                        // If we have both SET1 and SET2 students, alternate based on column
                        if (col % 2 == 1) { // Odd columns get SET1
                            studentInfo = set1Queue.poll();
                            setType = "SET1";
                        } else { // Even columns get SET2
                            studentInfo = set2Queue.poll();
                            setType = "SET2";
                        }
                    } else if (!set1Queue.isEmpty()) {
                        // Only SET1 students left
                        studentInfo = set1Queue.poll();
                        setType = "SET1";
                    } else if (!set2Queue.isEmpty()) {
                        // Only SET2 students left
                        studentInfo = set2Queue.poll();
                        setType = "SET2";
                    } else {
                        // Skip this seat if no more students
                        continue;
                    }
                    
                    // Get student, section, exam and subject info
                    Student student = studentInfo.getStudent();
                    String sectionName = studentInfo.getSectionName();
                    Exam exam = studentInfo.getExam();
                    Subject subject = studentInfo.getSubject();
                    
                    // Create seating arrangement
                    SeatingArrangement arrangement = SeatingArrangement.builder()
                            .exam(exam)
                            .room(room)
                            .seatNumber(overallSeatNumber++)
                            .rowNumber(row)
                            .columnNumber(col)
                            .studentId(student.getId().toString())
                            .studentName(student.getName())
                            .registrationNumber(student.getRegistrationNumber())
                            .sectionName(sectionName)
                            .setType(setType)
                            .examDate(exam.getExamDate())
                            .subjectCode(subject.getCode())
                            .subjectName(subject.getName())
                            .build();
                    
                    arrangements.add(arrangement);
                }
            }
        }
        
        return arrangements;
    }
    
    // Helper class to store student info along with their exam and subject
    @lombok.Data
    @lombok.AllArgsConstructor
    private static class StudentExamInfo {
        private Student student;
        private String sectionName;
        private Exam exam;
        private Subject subject;
    }

    public List<SeatingArrangementDTO> getSeatingArrangementsByExam(Long examId) {
        List<SeatingArrangement> arrangements = seatingArrangementRepository.findByExamId(examId);
        return arrangements.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    public List<SeatingArrangementDTO> getSeatingArrangementsByExamAndRoom(Long examId, Long roomId) {
        List<SeatingArrangement> arrangements = seatingArrangementRepository.findByExamIdAndRoomId(examId, roomId);
        return arrangements.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    public List<Map<String, Object>> getRoomsWithArrangements() {
        List<Object[]> roomData = seatingArrangementRepository.findRoomsWithArrangements();
        
        Map<Long, Map<String, Object>> roomsMap = new HashMap<>();
        
        for (Object[] data : roomData) {
            Long roomId = (Long) data[0];
            String roomNumber = (String) data[1];
            String blockName = (String) data[2];
            Integer floorNumber = (Integer) data[3];
            Long examCount = (Long) data[4];
            Long studentCount = (Long) data[5];
            
            if (!roomsMap.containsKey(roomId)) {
                Map<String, Object> roomInfo = new HashMap<>();
                roomInfo.put("roomId", roomId);
                roomInfo.put("roomNumber", roomNumber);
                roomInfo.put("blockName", blockName);
                roomInfo.put("floorNumber", floorNumber);
                roomInfo.put("examCount", examCount);
                roomInfo.put("studentCount", studentCount);
                
                // Fetch set types for the room
                List<String> setTypes = seatingArrangementRepository.findSetTypesByRoomId(roomId);
                roomInfo.put("setTypes", setTypes);
                roomInfo.put("exams", new ArrayList<>());
                
                roomsMap.put(roomId, roomInfo);
            }
        }
        
        return new ArrayList<>(roomsMap.values());
    }
    
    public List<SeatingArrangementDTO> getSeatingArrangementsByRoom(Long roomId) {
        List<SeatingArrangement> arrangements = seatingArrangementRepository.findByRoomId(roomId);
        return arrangements.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    public List<Map<String, Object>> getRoomsWithArrangementsByDate(LocalDate date) {
        try {
            // Get rooms with arrangements for the specified date
            List<Object[]> roomData = seatingArrangementRepository.findRoomsWithArrangementsByDate(date);
            
            Map<Long, Map<String, Object>> roomsMap = new HashMap<>();
            
            for (Object[] data : roomData) {
                Long roomId = (Long) data[0];
                String roomNumber = (String) data[1];
                String blockName = (String) data[2];
                Integer floorNumber = (Integer) data[3];
                Long examId = (Long) data[4];
                String examName = (String) data[5];
                String startTime = (String) data[6];
                String endTime = (String) data[7];
                Long studentCount = (Long) data[8];
                
                if (!roomsMap.containsKey(roomId)) {
                    Map<String, Object> roomInfo = new HashMap<>();
                    roomInfo.put("roomId", roomId);
                    roomInfo.put("roomNumber", roomNumber);
                    roomInfo.put("blockName", blockName);
                    roomInfo.put("floorNumber", floorNumber);
                    roomInfo.put("studentCount", studentCount);
                    roomInfo.put("exams", new ArrayList<Map<String, Object>>());
                    
                    // Fetch set types for this room
                    List<String> setTypes = seatingArrangementRepository.findSetTypesByRoomId(roomId);
                    roomInfo.put("setTypes", setTypes);
                    
                    roomsMap.put(roomId, roomInfo);
                } else {
                    // Update the student count by adding if this is a different exam
                    Map<String, Object> roomInfo = roomsMap.get(roomId);
                    Long currentCount = (Long) roomInfo.get("studentCount");
                    
                    // Check if we've already counted this exam
                    @SuppressWarnings("unchecked")
                    List<Map<String, Object>> exams = (List<Map<String, Object>>) roomInfo.get("exams");
                    boolean examExists = exams.stream()
                            .anyMatch(e -> examId.equals(e.get("examId")));
                    
                    if (!examExists) {
                        roomInfo.put("studentCount", currentCount + studentCount);
                    }
                }
                
                // Add exam info to the room's exam list
                Map<String, Object> examInfo = new HashMap<>();
                examInfo.put("examId", examId);
                examInfo.put("examName", examName);
                examInfo.put("startTime", startTime);
                examInfo.put("endTime", endTime);
                examInfo.put("studentCount", studentCount);
                
                @SuppressWarnings("unchecked")
                List<Map<String, Object>> examsList = (List<Map<String, Object>>) roomsMap.get(roomId).get("exams");
                
                // Check if this exam is already in the list
                boolean examExists = examsList.stream()
                        .anyMatch(e -> examId.equals(e.get("examId")));
                
                if (!examExists) {
                    examsList.add(examInfo);
                }
            }
            
            return new ArrayList<>(roomsMap.values());
        } catch (Exception e) {
            e.printStackTrace();
            return new ArrayList<>();
        }
    }
    
    public long getStudentCountForRoomAndDate(Long roomId, LocalDate date) {
        return seatingArrangementRepository.countStudentsByRoomIdAndDate(roomId, date);
    }
    
    public List<String> getSetTypesForRoom(Long roomId) {
        return seatingArrangementRepository.findSetTypesByRoomId(roomId);
    }

    @Transactional
    public void deleteSeatingArrangementsByExam(Long examId) {
        if (!examRepository.existsById(examId)) {
            throw new RuntimeException("Exam not found");
        }
        
        // Check if arrangements exist
        List<SeatingArrangement> arrangements = seatingArrangementRepository.findByExamId(examId);
        if (arrangements.isEmpty()) {
            throw new RuntimeException("No seating arrangements found for this exam");
        }
        
        seatingArrangementRepository.deleteByExamId(examId);
    }

    public boolean existsByExamId(Long examId) {
        return seatingArrangementRepository.existsByExamId(examId);
    }

    public List<Exam> getExamsWithArrangements() {
        // Query to get distinct exams that have seating arrangements
        List<Long> examIds = seatingArrangementRepository.findExamsWithArrangements();
        if (examIds.isEmpty()) {
            return Collections.emptyList();
        }
        return examRepository.findAllById(examIds);
    }

    public Map<String, Object> getSeatingArrangementStats() {
        Map<String, Object> stats = new HashMap<>();
        
        // Count total arrangements
        long count = seatingArrangementRepository.count();
        stats.put("count", count);
        
        // Get recent exams with arrangements
        List<Exam> recentExams = getExamsWithArrangements();
        recentExams.sort(Comparator.comparing(Exam::getExamDate).reversed());
        
        // Take top 5 most recent exams
        List<Map<String, Object>> recentArrangements = recentExams.stream()
            .limit(5)
            .map(exam -> {
                Map<String, Object> examInfo = new HashMap<>();
                examInfo.put("examId", exam.getId());
                examInfo.put("examName", exam.getExamName());
                examInfo.put("examDate", exam.getExamDate());
                examInfo.put("subjectCode", exam.getSubject() != null ? exam.getSubject().getCode() : "N/A");
                examInfo.put("subjectName", exam.getSubject() != null ? exam.getSubject().getName() : "N/A");
                // Count students for this exam
                long studentCount = seatingArrangementRepository.countByExamId(exam.getId());
                examInfo.put("studentCount", studentCount);
                return examInfo;
            })
            .collect(Collectors.toList());
        
        stats.put("recent", recentArrangements);
        
        return stats;
    }
    
    private SeatingArrangementDTO convertToDTO(SeatingArrangement arrangement) {
        // Handle possible null references
        Block block = null;
        Floor floor = null;
        
        if (arrangement.getRoom() != null) {
            if (arrangement.getRoom().getFloor() != null) {
                floor = arrangement.getRoom().getFloor();
                if (floor.getBlock() != null) {
                    block = floor.getBlock();
                }
            }
        }
        
        return SeatingArrangementDTO.builder()
                .id(arrangement.getId())
                .examId(arrangement.getExam().getId())
                .roomId(arrangement.getRoom().getId())
                .roomNumber(arrangement.getRoom().getRoomNumber())
                .blockName(block != null ? block.getName() : "Unknown Block")
                .floorNumber(floor != null ? floor.getFloorNumber() : 0)
                .seatNumber(arrangement.getSeatNumber())
                .rowNumber(arrangement.getRowNumber())
                .columnNumber(arrangement.getColumnNumber())
                .studentId(arrangement.getStudentId())
                .studentName(arrangement.getStudentName())
                .registrationNumber(arrangement.getRegistrationNumber())
                .sectionName(arrangement.getSectionName())
                .setType(arrangement.getSetType())
                .examDate(arrangement.getExamDate())
                .examName(arrangement.getExam().getExamName())
                .subjectCode(arrangement.getSubjectCode())
                .subjectName(arrangement.getSubjectName())
                .build();
    }
}

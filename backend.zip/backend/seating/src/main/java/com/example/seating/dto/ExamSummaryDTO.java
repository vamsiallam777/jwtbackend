package com.example.seating.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDate;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ExamSummaryDTO {
    private Long id;
    private String examName;
    private LocalDate examDate;
    private String startTime;
    private String endTime;
    private String examType;
    private String setType;
    private Long subjectId;
    private String subjectCode;
    private String subjectName;
}

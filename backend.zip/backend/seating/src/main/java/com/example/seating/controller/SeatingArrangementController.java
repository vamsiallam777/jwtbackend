package com.example.seating.controller;

import com.example.seating.dto.ExamSummaryDTO;
import com.example.seating.dto.RoomAvailabilityDTO;
import com.example.seating.dto.SeatingArrangementDTO;
import com.example.seating.dto.SeatingGenerationMultiRequest;
import com.example.seating.dto.SeatingGenerationRequest;
import com.example.seating.entity.Exam;
import com.example.seating.service.SeatingArrangementService;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/seating-arrangements")
@CrossOrigin("*")
@RequiredArgsConstructor
public class SeatingArrangementController {
    private final SeatingArrangementService seatingArrangementService;

    @GetMapping("/exams/date/{date}")
    public ResponseEntity<List<ExamSummaryDTO>> getExamsByDate(
            @PathVariable @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {
        List<Exam> exams = seatingArrangementService.getExamsByDate(date);
        List<ExamSummaryDTO> examDTOs = exams.stream()
                .map(this::convertToExamSummaryDTO)
                .collect(Collectors.toList());
        return ResponseEntity.ok(examDTOs);
    }

    private ExamSummaryDTO convertToExamSummaryDTO(Exam exam) {
        return ExamSummaryDTO.builder()
                .id(exam.getId())
                .examName(exam.getExamName())
                .examDate(exam.getExamDate())
                .startTime(exam.getStartTime())
                .endTime(exam.getEndTime())
                .examType(exam.getExamType().toString())
                .setType(exam.getSetType().toString())
                .subjectId(exam.getSubjectId())
                .subjectCode(exam.getSubject() != null ? exam.getSubject().getCode() : null)
                .subjectName(exam.getSubject() != null ? exam.getSubject().getName() : null)
                .build();
    }

    @GetMapping("/available-rooms/{examId}")
    public ResponseEntity<List<RoomAvailabilityDTO>> getAvailableRooms(@PathVariable Long examId) {
        return ResponseEntity.ok(seatingArrangementService.getAvailableRooms(examId));
    }

    @PostMapping("/generate")
    public ResponseEntity<?> generateSeatingArrangement(@RequestBody SeatingGenerationRequest request) {
        try {
            List<SeatingArrangementDTO> arrangements = seatingArrangementService.generateSeatingArrangement(request);
            return ResponseEntity.ok(arrangements);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    @PostMapping("/generate-multi")
    public ResponseEntity<?> generateMultiExamSeatingArrangement(@RequestBody SeatingGenerationMultiRequest request) {
        try {
            List<SeatingArrangementDTO> arrangements = seatingArrangementService.generateMultiExamSeatingArrangement(request);
            return ResponseEntity.ok(arrangements);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    @GetMapping("/exam/{examId}")
    public ResponseEntity<List<SeatingArrangementDTO>> getSeatingArrangementsByExam(@PathVariable Long examId) {
        return ResponseEntity.ok(seatingArrangementService.getSeatingArrangementsByExam(examId));
    }

    @GetMapping("/exam/{examId}/room/{roomId}")
    public ResponseEntity<List<SeatingArrangementDTO>> getSeatingArrangementsByExamAndRoom(
            @PathVariable Long examId, @PathVariable Long roomId) {
        return ResponseEntity.ok(seatingArrangementService.getSeatingArrangementsByExamAndRoom(examId, roomId));
    }

    @DeleteMapping("/exam/{examId}")
    public ResponseEntity<?> deleteSeatingArrangementsByExam(@PathVariable Long examId) {
        try {
            seatingArrangementService.deleteSeatingArrangementsByExam(examId);
            return ResponseEntity.ok(Map.of("message", "Seating arrangements deleted successfully"));
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(Map.of("error", e.getMessage()));
        }
    }

    @GetMapping("/exists/{examId}")
    public ResponseEntity<Map<String, Boolean>> checkSeatingArrangementExists(@PathVariable Long examId) {
        boolean exists = seatingArrangementService.existsByExamId(examId);
        return ResponseEntity.ok(Map.of("exists", exists));
    }

    @GetMapping("/existing-arrangements")
    public ResponseEntity<List<ExamSummaryDTO>> getExamsWithExistingArrangements() {
        List<Exam> exams = seatingArrangementService.getExamsWithArrangements();
        List<ExamSummaryDTO> examDTOs = exams.stream()
                .map(this::convertToExamSummaryDTO)
                .collect(Collectors.toList());
        return ResponseEntity.ok(examDTOs);
    }

    @GetMapping("/count")
    public ResponseEntity<Map<String, Object>> getArrangementsCount() {
        Map<String, Object> response = seatingArrangementService.getSeatingArrangementStats();
        return ResponseEntity.ok(response);
    }

    @GetMapping("/rooms-with-arrangements")
    public ResponseEntity<List<Map<String, Object>>> getRoomsWithSeatingArrangements() {
        List<Map<String, Object>> rooms = seatingArrangementService.getRoomsWithArrangements();
        return ResponseEntity.ok(rooms);
    }

    @GetMapping("/room/{roomId}")
    public ResponseEntity<List<SeatingArrangementDTO>> getSeatingArrangementsByRoom(@PathVariable Long roomId) {
        List<SeatingArrangementDTO> arrangements = seatingArrangementService.getSeatingArrangementsByRoom(roomId);
        return ResponseEntity.ok(arrangements);
    }

    @GetMapping("/rooms-with-arrangements/date/{date}")
    public ResponseEntity<List<Map<String, Object>>> getRoomsByDate(
            @PathVariable @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {
        try {
            List<Map<String, Object>> rooms = seatingArrangementService.getRoomsWithArrangementsByDate(date);
            return ResponseEntity.ok(rooms);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(500).body(Collections.emptyList());
        }
    }

    @GetMapping("/room/{roomId}/date/{date}/count")
    public ResponseEntity<Map<String, Object>> getStudentCountForRoomAndDate(
            @PathVariable Long roomId,
            @PathVariable @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {
        try {
            long count = seatingArrangementService.getStudentCountForRoomAndDate(roomId, date);
            List<String> setTypes = seatingArrangementService.getSetTypesForRoom(roomId);
            return ResponseEntity.ok(Map.of(
                "studentCount", count,
                "setTypes", setTypes
            ));
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(500).body(Map.of("error", "Failed to get count"));
        }
    }
}

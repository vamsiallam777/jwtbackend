package com.example.seating.entity;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;

@Entity
@Table(name = "seating_arrangement")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class SeatingArrangement {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @ManyToOne
    @JoinColumn(name = "exam_id", nullable = false)
    private Exam exam;
    
    @ManyToOne
    @JoinColumn(name = "room_id", nullable = false)
    private Room room;
    
    @Column(name = "seat_number", nullable = false)
    private Integer seatNumber;
    
    // Explicitly force the row_num column name
    @Column(name = "row_num", nullable = false)
    private Integer rowNumber;
    
    // Explicitly force the column_num column name
    @Column(name = "column_num", nullable = false)
    private Integer columnNumber;
    
    @Column(name = "student_id", nullable = false)
    private String studentId;
    
    @Column(name = "student_name", nullable = false)
    private String studentName;
    
    @Column(name = "registration_number", nullable = false)
    private String registrationNumber;
    
    @Column(name = "section_name", nullable = false)
    private String sectionName;
    
    @Column(name = "set_type", nullable = false)
    private String setType;
    
    @Column(name = "exam_date", nullable = false)
    private LocalDate examDate;
    
    @Column(name = "subject_code", nullable = true)
    private String subjectCode;
    
    @Column(name = "subject_name", nullable = true)
    private String subjectName;
}

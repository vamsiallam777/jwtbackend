package com.example.seating.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

@Component
public class DatabaseSchemaFix implements CommandLineRunner {

    private static final Logger logger = LoggerFactory.getLogger(DatabaseSchemaFix.class);
    
    @Autowired
    private JdbcTemplate jdbcTemplate;
    
    @Override
    public void run(String... args) throws Exception {
        logger.info("Checking seating_arrangement table schema...");
        try {
            // Check if the table exists, if not, do nothing (it will be created by Hibernate)
            jdbcTemplate.execute("SHOW TABLES LIKE 'seating_arrangement'");
            
            // Check if old column names exist and fix them
            try {
                jdbcTemplate.execute("ALTER TABLE seating_arrangement RENAME COLUMN row_number TO row_num");
                logger.info("Renamed column row_number to row_num");
            } catch (Exception e) {
                logger.debug("Column row_number doesn't exist or already renamed: {}", e.getMessage());
            }
            
            try {
                jdbcTemplate.execute("ALTER TABLE seating_arrangement RENAME COLUMN column_number TO column_num");
                logger.info("Renamed column column_number to column_num");
            } catch (Exception e) {
                logger.debug("Column column_number doesn't exist or already renamed: {}", e.getMessage());
            }
            
        } catch (Exception e) {
            // Table doesn't exist yet, it will be created with correct column names
            logger.debug("seating_arrangement table doesn't exist yet: {}", e.getMessage());
        }
        logger.info("Schema check complete");
    }
}
